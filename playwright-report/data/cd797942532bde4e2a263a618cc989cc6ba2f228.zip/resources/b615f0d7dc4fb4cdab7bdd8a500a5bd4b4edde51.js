/*Funcion para ver detalles de planes*/
var coll = document.getElementsByClassName("view-detail");
var i;
for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
        // Buscar el elemento .plan-det asociado
        var planDet = this.parentElement.querySelector(".plan-det");
        if (planDet) {
            planDet.classList.toggle("active");
            var isVisible = planDet.classList.contains("active");
            if (isVisible) {
                jQuery(planDet).show('200');
            } else {
                jQuery(planDet).hide('200');
            }
        }
    });
}
/*Segunda funcion para ver detalles de los kioskos*/
var colk = document.getElementsByClassName("view-detailk");
var ki;
for (ki = 0; ki < colk.length; ki++) {
    colk[ki].addEventListener("click", function () {
        this.classList.toggle("active");
        // Buscar el elemento .plan-det asociado
        var planDetk = this.parentElement.querySelector(".plan-detk");
        if (planDetk) {
            planDetk.classList.toggle("active");
            var isVisible = planDetk.classList.contains("active");
            if (isVisible) {
                jQuery(planDetk).show('200');
            } else {
                jQuery(planDetk).hide('200');
            }
        }
    });
}
/*Funcion para ver planes internet por ciudad*/
jQuery('#slcCityInternet').on('change', function () {
  var city = jQuery(this).find(":selected").val();
  /*Manta Machala Ambato Ibarra Loja*/
    if (city === 'MNT' || city === 'MAC' || city === 'AMB' || city === 'IBARRA' || city === 'LOJA') {
        jQuery('#tab-ciudades-hfc').show();
        jQuery('#tab-ciudades-regular').hide();
        jQuery('#tab-ciudades-gpon').hide();
    } else if (city === 'TULCAN' || city === 'RIOBAMBA' || city === 'SALINAS' || city === 'PORTO') {
        jQuery('#tab-ciudades-gpon').show();
        jQuery('#tab-ciudades-hfc').hide();
        jQuery('#tab-ciudades-regular').hide();
    } else {
        jQuery('#tab-ciudades-regular').show();
        jQuery('#tab-ciudades-hfc').hide();
        jQuery('#tab-ciudades-gpon').hide();
    }
});
/*Funcion para triplepack?
jQuery('#slcCityTriple').on('change', function () {
  var city = jQuery(this).find(":selected").val();
  /*Manta Machala Ambato Ibarra Loja
  if (city == 'TULCAN' || city == 'RIOBAMBA' || city == 'SALINAS' || city == 'PORTO'){
  		jQuery('#tab-ciudades-gpon').show();
  		jQuery('#tab-ciudades-regular').hide();
  }else{
  		jQuery('#tab-ciudades-regular').show();
  		jQuery('#tab-ciudades-gpon').hide();
  }
});*/
/*Funcion para cambiar las grillas de programacion*/
jQuery('#slcPlanTV').children('option[value="EPLUS"]').css('display', 'none');
jQuery('#slcPlanTV').children('option[value="ECON"]').css('display', 'none');
jQuery('#slcCityInternet').on('change', function () {
    var city = jQuery(this).find(":selected").val();
    var plan = jQuery("#slcPlanTV").find(":selected").val();
    if (city === 'IBARRA') {
        jQuery('#slcPlanTV').children('option[value="EPLUS"]').css('display', 'block');
        jQuery('#slcPlanTV').children('option[value="ECON"]').css('display', 'block');
    } else {
        jQuery('#slcPlanTV').children('option[value="EPLUS"]').css('display', 'none');
        jQuery('#slcPlanTV').children('option[value="ECON"]').css('display', 'none');
    }
    jQuery(".grillas").hide();
    jQuery("#" + city + " ." + plan).show();
});
jQuery('#slcPlanTV').on('change', function () {
    var plan = jQuery(this).find(":selected").val();
    var city = jQuery("#slcCityInternet").find(":selected").val();
    jQuery(".grillas").fadeOut();
    jQuery("#" + city + " ." + plan).fadeIn();
});
/*Mostrar la seleccion de planes regulares*/
jQuery('#slcPlanRegular').on('change', function () {
    var city = jQuery(this).find(":selected").val();
    jQuery(".plan-regular").fadeOut();
    jQuery(".plan-regular" + "#" + city).fadeIn();
});
/*Mostrar las islas con Kioskos o no*/
jQuery('#slcKiosko').on('change', function () {
    var haveKiosko = jQuery(this).find(":selected").val();
    jQuery(".vc_tta-container").fadeOut();
    jQuery(".vc_tta-container" + "#" + haveKiosko).fadeIn();
});
/*Version mobile(revisar)*/
jQuery('#slcMobilekiosko').on('change', function () {
    var haveKiosko = jQuery(this).find(":selected").val();
    jQuery(".vc_tta-container").fadeOut();
    jQuery(".vc_tta-container" + "#" + haveKiosko).fadeIn();
});
/*Mostrar la seleccion de ciudad para ver los # de Call Center*/
jQuery('#slcCallCenter').on('change', function() {
	var city = jQuery(this).find(":selected").val();
	jQuery(".call-center").fadeOut();
	jQuery(".call-center" + "#" + city).fadeIn();
});
/*Codigo para los tabs en version responsive*/
jQuery(document).ready(function ($) {
    // Añade desplazamiento horizontal suave al hacer clic en una pestaña
    $('.custom-mobile-tabs .vc_tta-tabs-list a').on('click', function (e) {
        e.preventDefault();
        var targetTab = $(this).attr('href');
        $('.custom-mobile-tabs .vc_tta-panels').animate({
            scrollLeft: $(targetTab).position().left
        }, 500);
    });
    // Cambia el comportamiento a desplazamiento horizontal en pantallas más pequeñas
    $(window).on('resize', function () {
        if ($(window).width() <= 768) {
            $('.custom-mobile-tabs .vc_tta-tabs-list').addClass('vc_tta-tabs-list-scroll');
        } else {
            $('.custom-mobile-tabs .vc_tta-tabs-list').removeClass('vc_tta-tabs-list-scroll');
        }
    });
    // Disparar el evento resize después de la carga para garantizar el comportamiento correcto
    $(window).trigger('resize');
});
/*Codificacion para traer tabla de datos de la guia telefonica*/
jQuery(document).ready(function ($) {
    $('#buscar-btn').on('click', function () {
        var codRegional = $('#codRegional').val();
        console.log(codRegional);
        var tipoBusqueda = $('#tipo-busqueda').val();
        console.log(tipoBusqueda);
        var valorBusqueda = $('#valor-busqueda').val();
        console.log(valorBusqueda);
        jQuery('.loader-container').css({
            'display': 'flex',
            'align-items': 'center',
            'justify-content': 'center'
        });
        // Realizar la petición AJAX a la base de datos
        $.ajax({
            url: "/wp-admin/admin-ajax.php",
            type: 'POST',
            data: {
                action: 'buscar_telefonos',
                codRegional: codRegional,
                tipoBusqueda: tipoBusqueda,
                valorBusqueda: valorBusqueda
            },
            success: function (response) {
                jQuery('.loader-container').css('display', 'none');
                // Mostrar los resultados en el contenedor de resultados
                $('#resultados').html(response);
            },
            error: function (error) {
                jQuery('.loader-container').css('display', 'none');
                console.log(error);
            }
        });
    });
});
/*Codigo para el chart de los indices de calidad*/
jQuery(document).ready(function ($) {
    // Reemplaza 'tu_archivo.csv' con la ruta correcta de tu archivo CSV
    $.get('https://www.xtrim.com.ec/wp-content/uploads/2023/12/Utilizacion-de-salida-internacional-xtrim-para-WP_1.csv', function (data) {
        var lines = data.split('\n');
        var labels = [];
        var porcentajes = [];
        var capacidad = [];
        for (var i = 1; i < lines.length; i++){
			var values = lines[i].split(',');
			labels.push(values[0]);
			capacidad.push(parseFloat(values[1]));
			porcentajes.push(parseFloat(values[2]));
		}
        console.log(labels, porcentajes); // Verifica en la consola si los datos se están llenando correctamente
        const labels1=[1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
        var ctx = document.getElementById('miGrafico').getContext('2d');
        var miGrafico = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels1,
                datasets: [
                    {
                        label: 'Utilización (%)',
                        borderColor: 'rgba(255, 207, 0, 1)',
                        data: porcentajes,
                        yAxisID: 'yPorcentaje'
                    },
                    {
                        label: 'Capacidad (Gbps)',
                        borderColor: 'rgba(63, 27, 106, 1)',
                        data: capacidad, // Rellena un array con 442 para la capacidad constante
                        yAxisID: 'yCapacidad'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom',
                        title: {
                            display: false,
                            text: 'Fecha'
                        },
                        ticks: {
                            stepSize: 1, //Ajusta según la densidad de tus datos
                            maxRotation: 90,
                            callback: function (value, index, values) {
                                var displayedLabel = labels[index];
                                //Si deseas mostrar solo un rango específico, puedes hacer algo como esto:
                                if (index % 3 === 0) {
                                    displayedLabel = labels[index];
                                } else {
                                    displayedLabel = '';
                                }
                                return displayedLabel;
                            }
                        }
                    },
                    yCapacidad: {
                        type: 'linear',
                        position: 'right',
                        min: 0,
                        max: 600, // Ajusta según tus necesidades
                        title: {
                            display: true,
                            text: 'Capacidad Salida Internacional (Gbps)'
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Capacidad (Gbps)'
                        }
                    },
                    yPorcentaje: {
                        type: 'linear',
                        position: 'left',
                        min: 0,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Porcentaje de Utilización'
                        },
                        scaleLabel: {
                            display: true,
                            labelString: 'Utilización (%)'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Porcentaje de Utilización Salida Internacional Xtrim',
                        position: 'top',
                        align: 'center',
                        font: {
                            size: 16
                        }
                    },
                    tooltip: {
                        enabled: true, // Deshabilita los tooltips predeterminados,
                        callbacks: {
                            // HERE YOU CUSTOMIZE THE LABELS
                            title : function (tooltipItems, data) {
                                // Verifica si tooltipItems es un array y tiene al menos un elemento
                                if (tooltipItems && tooltipItems.length > 0) {
                                    // Usamos el valor x del primer elemento del array
                                    console.log(tooltipItems);
                                    return tooltipItems[0].label + ' de Julio';
                                }
                                return '';
                                // Manejar el caso en que no hay elementos en tooltipItems
                            }
                        }
                    }
                }
            }
        });
    });
});
//Codigo para agregar el boton en el navbar version movil

jQuery(document).ready(function ($) {
    // Ocultar la sección de búsqueda en la versión móvil
    $('.handheld-header-links').hide();
    // Agregar el contenedor con el botón al lado del logo
    var headerLogo = $('.handheld-header-v2');
    if (headerLogo.length > 0) {
        var newContainer = $('<div></div>').addClass('contrata-online-button-container');
        var newButton = $('<a href="https://pagos.xtrim.com.ec/"></a>').addClass('contrata-online-button').text('Pagos Rápidos');
        newContainer.append(newButton);
        headerLogo.append(newContainer);
    }
});

//Codigo para agregar la seccion legal en el footer
jQuery(document).ready(function($) {
    // Seleccionar el contenedor del footer móvil
    var mobileFooter = $('.handheld-footer.d-lg-none.pt-3.v1 ');
    // Verificar si existe el contenedor del footer móvil
    if (mobileFooter.length > 0) {
        // Crear el nuevo contenedor para la barra de copyright
        var newContainer = $('<div></div>').addClass('copyright-bar');
        var newContent = $('<div class="container"><div class="float-start copyright"><a href="#"></a>© Xtrim 2024 - SERVICIOS DE TELECOMUNICACIONES SETEL S.A.</div><div class="float-end payment"></div></div>');
        // Agregar el nuevo contenido al contenedor
        newContainer.append(newContent);
        // Añadir el nuevo contenedor al footer móvil
        mobileFooter.append(newContainer);
    }
});

/*Funcion para aceptar solo numeros en forms*/
jQuery(document).ready(function () {
	jQuery( '.numbersOnly' ).keypress(function (e) {
		var charCode = (e.which) ? e.which : event.keyCode
		if (String.fromCharCode(charCode).match(/[^0-9]/g))    
			return false;                       
	});    
});

/*Funcion para el acordion personalizado*/
const items = document.querySelectorAll(".accordion button");

function toggleAccordion() {
  const itemToggle = this.getAttribute('aria-expanded');
  
  for (i = 0; i < items.length; i++) {
    items[i].setAttribute('aria-expanded', 'false');
  }
  
  if (itemToggle == 'false') {
    this.setAttribute('aria-expanded', 'true');
  }
}

items.forEach(item => item.addEventListener('click', toggleAccordion));


//Opcion select dentro de un acordion   
document.addEventListener("DOMContentLoaded", function() {
  const fileData = [
    {
        year: '2025',   
        documents: [
          { month: 'Noviembre', name: ' Noviembre 2025 Nuevos Planes Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/11/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-nuevos-planes-NOVIEMBRE.pdf' },
          { month: 'Noviembre', name: ' Noviembre 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/11/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-NOVIEMBRE-2025.pdf' },
          { month: 'Octubre', name: ' Octubre 2025 Retención Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/10/Planes_retencion_internet_residencial.pdf' },
          { month: 'Octubre', name: ' Octubre 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/10/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-OCTUBRE-2025-1.pdf' },
          { month: 'Septiembre', name: ' Septiembre 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/10/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-SEPTIEMBRE-2025-ACTUALIZADO.pdf' },
          { month: 'Agosto', name: ' Agosto 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/08/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-AGOSTO-2025.pdf' },
          { month: 'Julio', name: ' Julio 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/08/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-JULIO-actual.pdf' },   
          { month: 'Junio', name: ' Junio 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/06/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-JUNIO-2025-ACTUAL.pdf' },  
          { month: 'Mayo', name: ' Mayo 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/06/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-MAYO-2025-ACTUAL.pdf' },
          { month: 'Abril', name: ' Abril 2025 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/04/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-2025-ultima-version-abril.pdf' },
          { month: 'Abril', name: ' Abril 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/04/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-ACTUAL-ABRIL-2025.pdf' },
          { month: 'Marzo', name: ' Marzo 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/03/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-MARZO-2025-ACTUAL.pdf' },
          { month: 'Febrero', name: ' Febrero 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/02/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-FEBRERO-2025-Actualizado.pdf' },
          { month: 'Enero', name: ' Enero 2025 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/01/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIALENERO-2025.pdf' },
          { month: 'Enero', name: ' Enero 2025 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2025/01/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-2025-v2.pdf' },
        ]
      },
    {
      year: '2024',   
      documents: [
        { month: 'Diciembre', name: ' Diciembre 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/11/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-NOVIEMBRE-2024-2.pdf' },
        { month: 'Diciembre', name: ' Diciembre 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/12/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-2024-2.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/11/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-NOVIEMBRE-2024-2.pdf' },
        { month: 'Octubre', name: ' Octubre 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/10/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-OCTUBRE_2024-2.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/09/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-SEPTIEMBRE-2024-1-1.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/09/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-SEPTIEMBRE-2024.pdf' },
		{ month: 'Agosto', name: ' Agosto 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/08/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-AGOSTO-2024.pdf' },
		{ month: 'Julio', name: ' Julio 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/07/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-JULIO-2024-2.pdf' },
		{ month: 'Julio', name: ' Julio 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/07/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-2024-1.pdf' },
		{ month: 'Julio', name: ' Actualización de tarifas Internet Planes de Retención 2024', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/07/Precios-Internet-retencion_ago24.pdf' },
		{ month: 'Junio', name: ' Junio 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/06/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-ACTUALIZADO-JUNIO27-2024.pdf' },
		{ month: 'Mayo', name: ' Mayo 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/05/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO-2024.pdf' },
		{ month: 'Mayo', name: ' Mayo 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/05/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-MAYO-2024.pdf' },
        { month: 'Abril', name: ' Abril 2024 Internet Precios regulares', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/Precios-regulares-Internet-Residencial.pdf' },
        { month: 'Abril', name: ' Abril 2024 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/TERMINOS-CONDICIONES-TELEFONIA-2024.pdf' },
        { month: 'Abril', name: ' Abril 2024 Telefonía Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/TERMINOS-CONDICIONES-TELEFONIA-CORPORATIVA-2024.pdf' },
        { month: 'Abril', name: ' Abril 2024 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/TERMINOS-CONDICIONES-TELEVISION-2024.pdf' },
        { month: 'Abril', name: ' Abril 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/TERMINOS-Y-CONDICIONES-INTERNET-CORPORATIVO.pdf' },
        { month: 'Abril', name: ' Abril 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/05/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-ABRIL-2024-2.pdf' },
        { month: 'Marzo', name: ' Marzo 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/03/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL.pdf' },
        { month: 'Marzo', name: ' Marzo 2024 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/03/XTRIM-Terminos_y_Condiciones_TVPagada_FEBRERO_2024_NEW.pdf' },
		{ month: 'Marzo', name: ' Actualización de tarifas Internet Residencial 2024', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/03/Actualizacion-de-tarifas-Internet-Residencial-2024.pdf' },
        { month: 'Febrero', name: ' Febrero 2024 Internet Precios regulares', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/02/Precios-regulares-planes-Internet-Residencial-2.pdf' },
        { month: 'Febrero', name: ' Febrero 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/02/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-FEBRERO-2024-1.pdf' },
        { month: 'Febrero', name: ' Febrero 2024 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/02/TERMINOS-Y-CONDICIONES-TVPAGADA-FEBRERO-2024-NEW.pdf' },
        { month: 'Enero', name: ' Enero 2024 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-CONDICIONES-TELEFONIA-2024.pdf' },
        { month: 'Enero', name: ' Enero 2024 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-CONDICIONES-TELEFONIA-COMERCIAL-2024-1.pdf' },
        { month: 'Enero', name: ' Enero 2024 Telefonía Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-CONDICIONES-TELEFONIA-CORPORATIVA-2024.pdf' },
        { month: 'Enero', name: ' Enero 2024 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-2024.pdf' },
        { month: 'Enero', name: ' Enero 2024 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-Y-CONDICIONES-INTERNET-RESIDENCIAL-2024.pdf' },
        { month: 'Enero', name: ' Enero 2024 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/01/TERMINOS-Y-CONDICIONES-TVPAGADA-2024.pdf' },
      ]
    },
    {
      year: '2023',
      documents: [
        { month: 'Diciembre', name: ' Diciembre 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/12/Terminos-y-condiciones-Planes-Internet-Residencial-actual.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2023 Internet Precios regulares', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/11/Precios-regulares-planes-Internet-Residencial-1.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/11/TERMINOS-CONDICIONES-TELEFONIA-COMERCIAL.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2023 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2024/04/TERMINOS-CONDICIONES-TELEVISION-2024.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2023 Telefonía Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/11/TERMINOS-CONDICIONES-TELEFONIA-CORPORATIVA.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/11/Terminos-y-condiciones-Planes-Internet-Residencial-1.pdf' },
        { month: 'Octubre', name: ' Octubre 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/10/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-OCT-A-DIC-2023.pdf' },
        { month: 'Octubre', name: ' Octubre 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/10/Terminos-y-condiciones-Planes-Internet-Residencial-actualizado.pdf' },
        { month: 'Octubre', name: ' Octubre 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/10/TERMINOS-Y-CONDICIONES-TELEFONIA-OCT-DIC-2023.pdf' },
        { month: 'Octubre', name: ' Octubre 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/10/TERMINOS-Y-CONDICIONES-TVPAGADA-OCT-DIC-2023.pdf' },
        { month: 'Septiembre', name: ' Septiembre 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/09/Terminos-y-condiciones-Planes-Internet-Residencial-Septiembre-2023-actualizado.pdf' },
        { month: 'Agosto', name: ' Agosto 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/08/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-AGO-SEPT-2023.pdf' },
        { month: 'Agosto', name: ' Agosto 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/08/Terminos-y-condiciones-Planes-Internet-Residencial-Agosto-2023.pdf' },
        { month: 'Agosto', name: ' Agosto 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/08/TERMINOS-Y-CONDICIONES-TELEFONIA-AGO-SEPT-2023.pdf' },
        { month: 'Agosto', name: ' Agosto 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/08/TERMINOS-Y-CONDICIONES-TVPAGADA-AGO-SEPT-2023.pdf' },
        { month: 'Julio', name: ' Julio 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/07/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-JULIO-2023.pdf' },
        { month: 'Julio', name: ' Julio 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/07/Terminos-y-condiciones-Planes-Internet-Residencial-Julio-2023.pdf' },
        { month: 'Julio', name: ' Julio 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/07/TERMINOS-Y-CONDICIONES-TVPAGADA-JULIO-2023.pdf' },
        { month: 'Junio', name: ' Junio 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-JUNIO-2023.pdf' },
        { month: 'Junio', name: ' Junio 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/Terminos-y-condiciones-Planes-Internet-Residencial-Junio-2023.pdf' },
        { month: 'Junio', name: ' Junio 2023 Internet Residencial Nuevas Ciudades Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/Terminos-y-condiciones-Planes-y-Promocion-Ciudad-Santo-Domingo-y-Sectores-de-Quito.pdf' },
        { month: 'Junio', name: ' Junio 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/TERMINOS-Y-CONDICIONES-TELEFONIA.pdf' },
        { month: 'Junio', name: ' Junio 2023 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/TERMINOS-Y-CONDICIONES-TELEFONIA-COMERCIAL.pdf' },
        { month: 'Junio', name: ' Junio 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/06/TERMINOS-Y-CONDICIONES-TVPAGADA-JUNIO-023.pdf' },
        { month: 'Mayo', name: ' Mayo 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/05/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-MAYO-2023.pdf' },
        { month: 'Mayo', name: ' Mayo 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/05/Terminos-y-condiciones-Planes-Internet-Residencial-Mayo-2023-1.pdf' },
        { month: 'Mayo', name: ' Mayo 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/05/TERMINOS-Y-CONDICIONES-TVPAGADA-MAYO-2023.pdf' },
        { month: 'Abril', name: ' Abril 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/04/Terminos-y-condiciones-Planes-Internet-Abril-2023-V1-2.pdf' },
        { month: 'Abril', name: ' Abril 2023 Internet Promoción Temporada Salinas', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/04/Terminos-y-condiciones-Promo-temporada-Salinas-Guayaquil-1.pdf' },
        { month: 'Abril', name: ' Abril 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/04/TERMINOS-Y-CONDICIONES-TELEFONIA-ABRIL-MAYO-2023.pdf' },
        { month: 'Abril', name: ' Abril 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/04/TERMINOS-Y-CONDICIONES-TVPAGADA-ABRIL-2023.pdf' },
        { month: 'Marzo', name: ' Marzo 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/03/TERMINOS-Y-CONDICIONES-INT-CORPORATIVO-MARZO-2023.pdf' },
        { month: 'Marzo', name: ' Marzo 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/03/Terminos-y-condiciones-Planes-Internet-Marzo-2023.pdf' },
        { month: 'Marzo', name: ' Marzo 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/03/TERMINOS-Y-CONDICIONES-TELEFONIA-MARZO-2023.pdf' },
        { month: 'Marzo', name: ' Marzo 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/03/TERMINOS-Y-CONDICIONES-TVPAGADA-MARZO-2023.pdf' },
        { month: 'Febrero', name: ' Febrero 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/02/Terminos-y-condiciones-Planes-Internet-Febrero-2023.pdf' },
        { month: 'Enero', name: ' Enero 2023 Telefonía Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/WEB-telefonia-E1-ene23.pdf' },
        { month: 'Enero', name: ' Enero 2023 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/WEB-telefonia-comercial-ene23.pdf' },
        { month: 'Enero', name: ' Enero 2023 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/WEB-telefonia-residencial-ene23.pdf' },
        { month: 'Enero', name: ' Enero 2023 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/WEB-TV-residencial-ene23.pdf' },
        { month: 'Enero', name: ' Enero 2023 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/Terminos-y-condiciones-promo-Internet-Residencial-ENERO-20223_web.pdf' },
        { month: 'Enero', name: ' Enero 2023 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2023/01/PROMO-INT-CORPORATIVO-ENERO-2023_web.pdf' },
      ]
    },
	      {
      year: '2022',
      documents: [
        { month: 'Diciembre', name: ' Diciembre 2022 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/12/Terminos-y-condiciones-promo-Internet-Residencial-DICIEMBRE-2022-web.pdf' },
        { month: 'Noviembre', name: ' Noviembre 2022 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/11/Terminos-y-condiciones-promo-Internet-Residencial-Mundialista-y-Regular-NOV-DIC-2022.pdf' },
		{ month: 'Noviembre', name: ' Noviembre 2022 Internet Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/11/TERMINOS-PROMO-INT-CORPORATIVO-2-NOV-AL-31-DIC-2022.pdf ' },
        { month: 'Octubre', name: ' Octubre 2022 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/10/web-telf-residencial-oct22.pdf' },
        { month: 'Octubre', name: ' Octubre 2022 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/10/web-tv-pagada-oct22.pdf' },
        { month: 'Septiembre', name: ' Septiembre 2022 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/09/PROMO-INT-CORPORATIVO-2-SEPT-AL-31-OCT-2022.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2022 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/ web-tv-pagada-sept22.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2022 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/ web-telefonia-sept22.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2022 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/09/web-telf-comercial-sept22-3.pdf' },
		{ month: 'Septiembre', name: ' Septiembre 2022 Telefonía Corporativa Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/09/web-telf-corporativa-sept22-3.pdf' },
        { month: 'Agosto', name: ' Agosto 2022 Internet Corporativo Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/PROMO-INT-CORPORATIVO-1-AL-31-AGOSTO-2022.pdf' },
        { month: 'Agosto', name: ' Agosto 2022 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/Terminos-y-condiciones-promo-Internet-Residencial-Agosto-2022-actualizado-web-1.pdf' },
		{ month: 'Agosto', name: ' Agosto 2022 Internet Residencial Plan Mundialista Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/Terminos-y-condiciones-promo-Internet-Residencial-Mundialista-y-Regular.pdf' },
        { month: 'Agosto', name: ' Agosto 2022 Telefonía Comercial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/Promocion-Telefonia-Comercial-ENERO-ABRIL-2022.pdf' },
		{ month: 'Agosto', name: ' Agosto 2022 Telefonía Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/web-telefonia-agosto22.pdf' },
		{ month: 'Agosto', name: ' Agosto 2022 Telefonía Residencial E1 Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/Promocion-Telefonia-E1-ENERO-ABRIL-2022.pdf' },
        { month: 'Agosto', name: ' Agosto 2022 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/08/web-TV-PAGADA-agosto2022.pdf' },
        { month: 'Julio', name: ' Julio 2022 Internet Residencial Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/07/Terminos-y-condiciones-promo-Internet-Residencial-Julio-2022-web.pdf' },
        { month: 'Julio', name: ' Julio 2022 Televisión Pagada Términos y Condiciones', url: 'https://www.xtrim.com.ec/wp-content/uploads/2022/07/CONDICIONES-Y-RESTRICCIONES-TV-PAGADA-may-jun2022.pdf' },
      ]
    }
  ];

  const yearSelect = document.getElementById("yearSelect");
  const monthSelect = document.getElementById("monthSelect");
  const fileListContainer = document.getElementById("file-list-container");

  function populateMonths(year) {
    // Buscar los documentos correspondientes al año seleccionado
    const documentsOfYear = fileData.find(item => item.year === year).documents;
    
    // Obtener una lista de todos los meses para el año seleccionado
    const months = documentsOfYear.map(doc => doc.month);
    
    // Eliminar duplicados y ordenar descendentemente
    const uniqueMonths = [...new Set(months)].sort((a, b) => {
        return new Date('2000 ' + b) - new Date('2000 ' + a);
    });

    // Limpiar el selector de meses
    monthSelect.innerHTML = '';

    // Crear opción predeterminada "Seleccione un mes" y agregarla al selector
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Mes';
    monthSelect.appendChild(defaultOption);

    // Crear opciones para cada mes y agregarlas al selector
    uniqueMonths.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = month;
        monthSelect.appendChild(option);
    });

    // Habilitar el selector de meses
    monthSelect.disabled = false;

    // Remover la opción "Seleccione el año"
    const selectYearOption = yearSelect.querySelector('option[value=""]');
    if (selectYearOption) {
        selectYearOption.remove();
    }
}

  function filterFiles() {
    const selectedYear = yearSelect.value;
    const selectedMonth = monthSelect.value;

    // Filtrar los archivos según el año y el mes seleccionado
    const filteredFiles = fileData.find(item => item.year === selectedYear).documents.filter(doc => {
      return selectedMonth === '' || doc.month === selectedMonth;
    });

    // Mostrar los archivos filtrados en el contenedor
    renderFiles(filteredFiles);
  }

  function renderFiles(files) {
    // Limpiar el contenedor
    fileListContainer.innerHTML = '';

    // Crear elementos HTML para cada archivo y agregarlos al contenedor
    files.forEach(file => {
        const fileLink = document.createElement('a');
        fileLink.setAttribute('href', file.url);
        fileLink.setAttribute('target', '_blank');
        fileLink.textContent = file.name;
        fileLink.style.color = "#0D58C1";

        const fileIcon = document.createElement('i');
        fileIcon.classList.add('far', 'fa-file-pdf');

        const fileItem = document.createElement('div');
        fileItem.classList.add('file-item');
        fileItem.appendChild(fileIcon);
        fileItem.appendChild(fileLink);

        fileListContainer.appendChild(fileItem);
    });
}

// Escuchar cambios en los selects y filtrar los archivos
yearSelect.addEventListener("change", function() {
  const selectedYear = yearSelect.value;
  if (selectedYear !== "") {
      populateMonths(selectedYear); // Actualiza los meses según el año seleccionado
  } else {
      monthSelect.innerHTML = ''; // Limpiar el selector de meses si no se ha seleccionado un año
      monthSelect.disabled = true; // Deshabilitar el selector de meses si no se ha seleccionado un año
      filterFiles(); // Filtrar archivos si no se ha seleccionado un año
  }
});

monthSelect.addEventListener("change", function() {
  const selectedMonth = monthSelect.value;
  if (selectedMonth !== "") {
      const selectMonthOption = monthSelect.querySelector('option[value=""]');
      if (selectMonthOption) {
          selectMonthOption.remove(); // Remover la opción "Seleccione un mes" si se ha seleccionado un mes
      }
  }
  filterFiles();
});

// Mostrar todos los archivos al cargar la página
filterFiles();
});



/*Funcion para llenar contenido en solicitudes*/
document.addEventListener('DOMContentLoaded', function () {
  const options = document.querySelectorAll('.option_solicitud');

  const contents = {
      contenido1: `
          <div>
              <h3 class="subtitulo_content">¿Cómo realizo un cambio de forma de pago?</h3>
                <ul class="items_content">
                    <li>Los pagos del servicio deben estar al día antes de solicitar el cambio.</li>
                    <li>La cuenta o tarjeta de crédito debe pertenecer al titular del contrato.</li>
                    <li>La cuenta o tarjeta de crédito deberá encontrarse activa.</li>
                    <li>El formulario de autorización de débito bancario debe estar firmado por el titular del contrato.</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                    <!-- <li>Este trámite lo puede realizar desde cualquier canal presencial o digital de autoservicio Xtrim.</li>
                <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/cambiar-forma-pago" target="_blank" title="Cambio Forma de Pago">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Cambio Forma de Pago">aquí</a>.</li>
                <li class="app_responsive_desktop">Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app. Escanea el siguiente QR para descargarla.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                    <li class="app_responsive_mobile">Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app. Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`,
      contenido2: `
          <div>
              <h3 class="subtitulo_content">¿Cómo realizo un cambio de titular?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de realizar el cambio de titular.</li>
                    <li>Cédula de identidad del actual titular, cédula de identidad del nuevo titular.</li>
                    <li>Adjuntar Formulario de cambio de titular debidamente completado y firmado por el titular actual y nuevo titular.</li>
                    <li>En caso de registrar un débito bancario, el nuevo titular debe descargar el formulario de autorización correspondiente y firmarlo.</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                    <!-- <li>Este trámite lo puede realizar desde cualquier canal presencial o digital de autoservicio Xtrim.</li>
                <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/cambio-titular" target="_blank" title="Cambio de Titular">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Cambio de Titular">aquí</a>.</li>

                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`,
      contenido3: `
          <div>
              <h3 class="subtitulo_content">¿Cómo solicito mi convenio de pago?</h3>
                <ul class="items_content">
                    <li>No deberás contar con un convenio activo.</li>
                    <li>Esta oferta es válida para clientes con una antigüedad superior a 6 meses y un saldo adeudado de al menos $50.</li>
                    <li>La deuda puede diferirse en cuotas de 3, 4, o 6 meses.</li>
                    <li>Una vez que solicites el convenio, la primera cuota estará activa de inmediato. Las siguientes cuotas se añadirán a tus facturas mensuales emitidas posteriormente.</li>
                    <li>En caso de incumplir con los pagos requeridos y caer en mora, el convenio no será eliminado y no se permitirá acceder a uno nuevo.</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/convenio-pago" target="_blank" title="Convenio de Pago">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Convenio de Pago">aquí</a>.</li>

                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`,
      contenido4: `
          <div>
              <h3 class="subtitulo_content">¿Quieres reubicar tus equipos a una nueva dirección?</h3>
                <ul class="items_content">
                    <li>Lleva tus equipos a tu nueva dirección.</li>
                    <li>Nuestros técnicos se encargarán de la instalación.</li>
                    <li>Precio de instalación para Conexión Híbrida: $17.86 + impuestos</li>
                    <li>Precio de instalación para Fibra Óptica: $35 + impuestos</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/cambio-direccion" target="_blank" title="Cambio de Dirección">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Cambio de Dirección">aquí</a>.</li>

                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`,
      contenido5: `
          <div>
              <h3 class="subtitulo_content">¿Cómo solicito mi beneficio por discapacidad?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de solicitar el beneficio.</li>
                    <li>Cédula actualizada con información de discapacidad.</li>
                    <li>Planilla de servicios básicos del lugar de instalación del servicio, en caso de no ser vivienda propia el Contrato de arrendamiento notariado a nombre del titular o cónyuge.</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/beneficios-discapacidad" target="_blank" title="Beneficio Discapacidad">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Beneficio Discapacidad">aquí</a>.</li>

                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`,
      contenido6: `
          <div>
              <h3 class="subtitulo_content">¿Cómo solicito mi beneficio como 3era. Edad?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de solicitar el beneficio.</li>
                    <li>El titular del contrato debe haber cumplido 65 años.</li>
                    <li>Cédula/pasaporte del titular del contrato.</li>
                    <li>Planilla de servicios básicos del lugar de instalación del servicio, en caso de no ser vivienda propia el Contrato de arrendamiento notariado a nombre del titular o cónyuge.</li>
                    <li>Adjuntar formulario de beneficios de tercera edad.</li>
                    <li>Este trámite lo puedes realizar desde cualquier canal presencial o llamando a nuestro <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">Call Center</a>.</li>
                <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/beneficios-3ra-edad" target="_blank" title="Beneficio 3era Edad">aquí</a>.</li>
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Beneficio 3era Edad">aquí</a>.</li>

                <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
          </div>`
  };

  function updateContent(contentKey) {
      return contents[contentKey];
  }

function handleNavigation() {
    const hash = location.hash.substring(1);
    if (hash) {
        const section = document.querySelector(`.option_solicitud[data-content="${hash}"]`);
        if (section) {
            options.forEach(opt => opt.classList.remove('selected'));
            section.classList.add('selected');
            const contentKey = section.getAttribute('data-content');
            const contentDiv = document.getElementById('content_solicitud');
            contentDiv.innerHTML = updateContent(contentKey);
			attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
        }
    }
}

options.forEach(option => {
    option.addEventListener('click', function () {
        const contentKey = option.getAttribute('data-content');
        options.forEach(opt => opt.classList.remove('selected', 'active'));
        option.classList.add(window.innerWidth <= 768 ? 'active' : 'selected');

        if (window.innerWidth <= 768) {
            // Mobile view
            const nextElement = option.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_solicitud')) {
                nextElement.remove();
            }
            option.insertAdjacentHTML('afterend', `<div class="content_solicitud">${updateContent(contentKey)}</div>`);
			attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
            history.pushState(null, null, `#${contentKey}`);
        } else {
            // Desktop view
            const contentDiv = document.getElementById('content_solicitud');
            contentDiv.innerHTML = updateContent(contentKey);
			attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
            history.pushState(null, null, `#${contentKey}`);
        }
    });
});

// Show the first option by default on desktop
if (window.innerWidth > 768) {
    const firstSelected = document.querySelector('.option_solicitud.selected');
    if (firstSelected) {
        firstSelected.click();
    }
}

// Synchronize between mobile and desktop views
function handleScreenSizeChange() {
    const mobileMediaQuery = window.matchMedia('(max-width: 768px)');
    if (mobileMediaQuery.matches) {
        // Mobile screen size detected
        options.forEach(opt => opt.classList.remove('selected'));
    } else {
        // Desktop screen size detected
        options.forEach(opt => {
            const nextElement = opt.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_solicitud')) {
                nextElement.remove();
            }
        });
    }
}

handleScreenSizeChange();
window.addEventListener('resize', handleScreenSizeChange);
window.addEventListener('popstate', handleNavigation);
handleNavigation(); // Load the correct view on page load
	
	
/*Modal mantenimiento*/
// Function to attach modal event listeners
function attachModalEventListeners() {
    var modal = document.getElementById("myModal_mantenimiento");

    var openModalElements = document.querySelectorAll('.open-modal_mantenimiento');

    openModalElements.forEach(function(element) {
        element.onclick = function(event) {
            event.preventDefault();
            modal.style.display = "flex";
        };
    });

    var span = document.getElementsByClassName("close_mantenimiento")[0];

    span.onclick = function() {
      modal.style.display = "none";
    };

    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    };
}

// Initial call to attach modal event listeners
attachModalEventListeners();
	
	
});


/*Funcion para llenar contenido en facturacion y pago*/
document.addEventListener('DOMContentLoaded', function () {
  const options = document.querySelectorAll('.option_facts');

  const contents = {
    contenido1f: `
        <div>
            <h3 class="subtitulo_content">¿Qué es Historial de Facturas?</h3>
            <p class="items_content">Es un registro de todas las facturas que has recibido por tu(s) servicio(s) Xtrim.</p>
<!-- <p class="items_content">Puedes revisar el historial y detalles de tus facturas desde nuestros canales digitales <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">Mi Xtrim App</a> y <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> -->
            <p class="items_content">Puedes revisar el historial y detalles de tus facturas desde nuestros canales digitales <a class="open-modal_mantenimiento" style="cursor:pointer;" title="App Mi Xtrim">Mi Xtrim App</a> y <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>
            <p class="items_content">Si deseas revisar tus últimas seis facturas, puedes hacerlo fácilmente desde Mi Xtrim Web:</p>
            <ul class="items_content">
<!-- <li>Inicia sesión en <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</li> -->
                <li>Inicia sesión en <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</li>
                <li>Una vez dentro, dirígete a la opción <b>"Historial de factura"</b>.</li>
                <li>Si tienes más de una cuenta, identifica una para visualizar el historial.</li>
                <li>Selecciona la factura que deseas revisar y presiona el botón <b>"Descargar"</b> para ver los detalles.</li>
            </ul>
        </div>`, 
     contenido2f: `
          <div>
              <h3 class="subtitulo_content">¿Dónde puedo consultar mi saldo?</h3>
              <p class="items_content">Puedes revisar tu(s) saldo(s) desde el WhatsApp, a través de nuestro Chatbot escribiendo al número <b>0968600400</b> o comunicándote a nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</p>
 <!-- <ul class="items_content">
    <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
    <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
<li>Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a>.</li>
    <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
    <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
    <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
<li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li>
</ul> -->
          </div>`,
      contenido3f: `
          <div>
              <h3 class="subtitulo_content">¿Dónde puedo revisar mi historial de facturas?</h3>
              <p class="items_content">Puedes revisarlo en nuestra portal y app de autoservicio Mi Xtrim ingresando con tu usuario y contraseña.</p>
              <ul class="items_content">
              <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                  <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                  <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                  <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
<!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
              </ul>
          </div>`,
      contenido4f: `
          <div>
              <h3 class="subtitulo_content">¿Dónde puedo realizar mis pagos?</h3>
              <p class="items_content">Puedes realizar tus pagos a través de nuestro <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatbot</a> o de manera presencial en los puntos autorizados de pago. Conoce la <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">red de pagos</a>.</p>
 <!-- <p class="items_content">Puedes realizar tus pagos sin filas con tus tarjetas bancarias, a través de nuestra web y app de autoservicio <b>Mi Xtrim</b> ingresando con tu usuario y contraseña, escribiendo en WhatsApp a nuestro <b>Chatbot</b> al 0968600400, o en nuestros Kioskos.</p>
 <ul class="items_content">
     <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
     <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
     <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
     <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
     <li>Ver <a href="https://www.xtrim.com.ec/kioscos/" target="_blank" title="Kioscos">Kioscos</a>.</li>
     <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
<li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li>
 </ul>
 <p class="items_content">Si tu forma de pago es Efectivo, puedes pagar a través de ventanillas bancarias, Banco del Barrio, Mi Vecino, Western Union, o Red de Servicios Facilito.</p>
 <ul class="items_content">
     <li>Ver <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">Puntos de Pago Autorizados </a>.</li>
 </ul> -->
          </div>`,
      contenido5f: `
          <div>
              <h3 class="subtitulo_content">¿Cómo puedo realizar mis pagos?</h3>
              <p class="items_content">Puedes realizar tus pagos de la siguiente forma:</p>
              <ul class="items_content">
                <li>Ingresa a nuestro <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatbot</a> para realizar tu pago en línea.</li>
                <li>Realiza tu pago de manera presencial en los <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">Puntos de Pago Autorizados </a>.</li>
              </ul>
 <!-- <p class="items_content">Puedes realizar tus pagos sin filas con tus tarjetas bancarias, a través de nuestra web y app de autoservicio <b>Mi Xtrim</b> ingresando con tu usuario y contraseña, escribiendo en WhatsApp a nuestro <b>Chatbot</b> al 0968600400, o en nuestros Kioskos.</p>
 <ul class="items_content">
     <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
     <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
     <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
     <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
     <li>Ver <a href="https://www.xtrim.com.ec/kioscos/" target="_blank" title="Kioscos">Kioscos</a>.</li>
     <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
<li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li>
 </ul>
 <p class="items_content">Si tu forma de pago es Efectivo, puedes pagar a través de ventanillas bancarias, Banco del Barrio, Mi Vecino, Western Union, o Red de Servicios Facilito.</p>
 <ul class="items_content">
     <li>Ver <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">Puntos de Pago Autorizados </a>.</li>
 </ul> -->
          </div>`,    
      contenido6f: `
          <div>
              <h3 class="subtitulo_content">¿Puedo actualizar mi forma de pago?</h3>
              <p class="items_content">Si, puedes actualizar tu forma de pago a débito automático acercándote a nuestras oficinas a nivel nacional. Considera los siguientes puntos:</p>
              <ul class="items_content">
                    <li>Los pagos del servicio deben estar al día antes de solicitar el cambio.</li>
                    <li>La cuenta o tarjeta de crédito debe pertenecer al titular del contrato.</li>
                    <li>La cuenta o tarjeta de crédito deberá encontrarse activa.</li>
                    <li>Descarga el formulario <a href="https://www.xtrim.com.ec/wp-content/uploads/2024/01/231026-AUTORIZACION-DE-DEBITO-AUTOMATICO.pdf" target="_blank" title="Cambio forma de Pago">aquí</a>.</li>
                    <li>Completa los datos del formulario y firmarlo.</li>
                    <li>Elige el centro de atención al cliente de tu preferencia <a href="https://www.xtrim.com.ec/agencias/" target="_blank" title="Agencias">Ver Agencias</a>.</li>
                    <li>Acércate a la agencia con el formulario y tu documento de identidad.</li>
              </ul>
<!-- <ul class="items_content">
    <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
    <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
    <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
    <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
    <li>Descarga el formulario <a href="https://www.xtrim.com.ec/wp-content/uploads/2024/01/231026-AUTORIZACION-DE-DEBITO-AUTOMATICO.pdf" target="_blank" title="Cambio forma de Pago">aquí</a>.</li>
    <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
<li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li>
</ul> -->
          </div>`,
      contenido7f: `
              <div>
                  <h3 class="subtitulo_content">¿Cuándo debo pagar mis facturas?</h3>
                  <p class="items_content">Realiza el pago de tus facturas los <b>primeros 10 días de cada mes</b>. Disfruta de tu servicio sin interrupciones realizando tus pagos a tiempo.</p>
                  <ul class="items_content">
                    <li>Si tu pago es en <b>Efectivo</b> puedes realizarlo a través de los canales autorizados. Conoce donde puede realizar tus pagos: <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Portal Web Mi Xtrim">Ir a Red de Pagos</a>.</li>
                    <li>Si tu forma de pago es <b>Débito Automático</b>, mantener los fondos correspondientes al monto de tu factura para se pueda realizar el débito.</li>
                    <li>Si vas a realizar el pago de tu <b>Primera factura</b>, debes tener en consideración lo siguiente:</li>
                    <ul class="items_content" style="list-style: none;">
                        <li>Tu factura se enviará a tu correo electrónico al día siguiente de activar el servicio. </li>
                        <li>Si la instalación se realiza después del día 20, los días proporcionales se sumarán a la factura del mes siguiente. El 1 del mes siguiente recibirás una factura que incluirá el valor del mes en curso, junto con el proporcional correspondiente al mes de activación.</li>
                    </ul>
                  </ul>
                  <p class="items_content">Recuerda que tus promociones se encuentran relacionadas a la puntualidad de tus pagos, evita perder los beneficios de tu contrato manteniéndote al día en tus pagos.</p>

 <!-- <p class="items_content">Si tu pago es en <b>Efectivo</b> puedes realizarlo a través de los canales autorizados:</p>
 <p class="items_content"><b>Presenciales</b></p>
 <ul class="items_content">
   <li>Red de Pagos <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Portal Web Mi Xtrim">aquí</a>.</li>
 </ul>
 <p class="items_content"><b>Digitales</b></p>
 <ul class="items_content">
   <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
   <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
   <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
 </ul>
 <p class="items_content">Si tu forma de pago es <b>Débito Automático</b>, mantener los fondos correspondientes al monto de tu factura para se pueda realizar el débito.</p>
 <p class="items_content">Si vas a realizar el pago de tu <b>Primera factura</b>, debes tener en consideración lo siguiente: </p>
 <ul class="items_content">
   <li>Tu factura se enviará a tu correo electrónico al día siguiente de activar el servicio.</li>
   <li>Si la instalación se realiza después del día 20, los días proporcionales se sumarán a la factura del mes siguiente. El 1 del mes siguiente recibirás una factura que incluirá el valor del mes en curso, junto con el proporcional correspondiente al mes de activación.</li>
 </ul>
 <p class="items_content">Recuerda que tus promociones se encuentran relacionadas a la puntualidad de tus pagos, evita perder los beneficios de tu contrato manteniéndote al día en tus pagos.</p> -->
              </div>` ,
      contenido8f: `
              <div>
                  <h3 class="subtitulo_content">¿Por qué mi forma de pago cambió a efectivo?</h3>
                  <p class="items_content">Este cambio se realiza automáticamente cuando hemos intentado procesar el débito correspondiente a tu(s) factura(s) de tu cuenta bancaria o tarjeta de crédito en varias ocasiones sin éxito. Esto puede deberse a:</p>
                  <ul class="items_content">
                      <li>Fondos insuficientes.</li>
                      <li>Tarjeta caducada.</li>
                      <li>Cuenta cerrada o bloqueada.</li>
                  </ul>
                  <p class="items_content">Al realizarse este cambio, los beneficios promocionales que disfrutabas podrían verse afectados, es decir, podrías perder megas adicionales, descuentos por forma de pago con el que fue contratado el servicio o plataformas de streaming adicionales. Te recomendamos mantener siempre actualizados tus datos bancarios y validar la información de tu forma de pago en caso de que tus pagos no hayan sido debitados a tiempo.</p>
              </div>`,
      contenido9f: `
              <div>
                  <h3 class="subtitulo_content">¿Por qué incrementó mi facturación?</h3>
                  <p class="items_content">Si has notado un aumento en tu facturación, podría deberse a varios motivos. A continuación, te explicamos algunas de las razones más comunes:</p>
                  <p class="items_content">1. <b>Visitas Técnicas:</b> Las órdenes técnicas que son facturadas tienen los siguientes costos según el tipo de red: </p>
                  <ul class="items_content">
                      <li><b>Conexión Hibrida:</b> $15 + impuestos.</li>
                      <li><b>Fibra Óptica:</b> $20 + impuestos.</li>  
                  </ul>
                  <p class="items_content">2. <b>Cambio de Dirección:</b> Las peticiones de cambio de dirección solicitadas por el cliente tienen costo según el tipo de red: </p>  
                  <ul class="items_content">
                        <li><b>Conexión Hibrida:</b> $17.85 + impuestos.</li>
                        <li><b>Fibra Óptica:</b> $35 + impuestos.</li>  
                  </ul>
                  <p class="items_content">3. <b>Productos o Servicios Adicionales:</b> Los productos adicionales tienen los siguientes costos: </p>
                  <ul class="items_content">
                    <li><b>Max:</b> $5.99 incl. impuestos.</li>
                    <li><b>Paramount+:</b> $4.99 incl. impuestos.</li>
                    <li><b>ECDF:</b> $9.99 incl. impuestos.</li>
                    <li><b>Wifi Elite:</b> $4.60 incl. impuestos.</li>
                    <li><b>Control Remoto:</b> Por la compra de un control: $10 + impuestos.</li>
                    <li><b>Tv Box:</b> Por la compra de un equipo Tv Box.</li>
                    <li style="list-style-type: none;">
                      <ul class="items_content">
                        <li><b>Pago de Contado:</b> $70 + impuestos.</li>
                      </ul>
                    </li>
                    <li style="list-style-type: none;">
                      <ul class="items_content">
                        <li><b>Pago de Diferido:</b> $85 + impuestos.</li>
                      </ul>
                    </li>
                  </ul>
<!-- <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> 
                  <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>-->
              </div>`,
        contenido10f: `
              <div>
                  <h3 class="subtitulo_content">¿Por qué aparezco reportado en el buró de crédito?</h3>
                  <ul class="items_content">
                      <li>Aparecer en el buró de crédito puede ocurrir por diferentes motivos relacionados con el manejo tus pagos en el pasado. El motivo principal es por valores no cancelados oportunamente de tus servicios.</li>
                  </ul>
<!-- <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> 
                  <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>-->
              </div>`        
  };

  function updateContent(contentKey) {
      return contents[contentKey];
  }

function handleNavigation() {
    const hash = location.hash.substring(1);
    if (hash) {
        const section = document.querySelector(`.option_facts[data-content="${hash}"]`);
        if (section) {
            options.forEach(opt => opt.classList.remove('selected'));
            section.classList.add('selected');
            const contentKey = section.getAttribute('data-content');
            const contentDiv = document.getElementById('content_facts');
            contentDiv.innerHTML = updateContent(contentKey);
		    attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
        }
    }
}

options.forEach(option => {
    option.addEventListener('click', function () {
        const contentKey = option.getAttribute('data-content');
        options.forEach(opt => opt.classList.remove('selected', 'active'));
        option.classList.add(window.innerWidth <= 768 ? 'active' : 'selected');

        if (window.innerWidth <= 768) {
            // Mobile view
            const nextElement = option.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_facts')) {
                nextElement.remove();
            }
            option.insertAdjacentHTML('afterend', `<div class="content_facts">${updateContent(contentKey)}</div>`);
			attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
            history.pushState(null, null, `#${contentKey}`);
        } else {
            // Desktop view
            const contentDiv = document.getElementById('content_facts');
            contentDiv.innerHTML = updateContent(contentKey);
			attachModalEventListeners(); // Reasignar los eventos después de actualizar el contenido
            history.pushState(null, null, `#${contentKey}`);
        }
    });
});

// Show the first option by default on desktop
if (window.innerWidth > 768) {
    const firstSelected = document.querySelector('.option_facts.selected');
    if (firstSelected) {
        firstSelected.click();
    }
}

// Synchronize between mobile and desktop views
function handleScreenSizeChange() {
    const mobileMediaQuery = window.matchMedia('(max-width: 768px)');
    if (mobileMediaQuery.matches) {
        // Mobile screen size detected
        options.forEach(opt => opt.classList.remove('selected'));
    } else {
        // Desktop screen size detected
        options.forEach(opt => {
            const nextElement = opt.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_facts')) {
                nextElement.remove();
            }
        });
    }
}

handleScreenSizeChange();
window.addEventListener('resize', handleScreenSizeChange);
window.addEventListener('popstate', handleNavigation);
handleNavigation(); // Load the correct view on page load
	

/*Modal mantenimiento*/
// Function to attach modal event listeners
function attachModalEventListeners() {
    var modal = document.getElementById("myModal_mantenimiento");

    var openModalElements = document.querySelectorAll('.open-modal_mantenimiento');

    openModalElements.forEach(function(element) {
        element.onclick = function(event) {
            event.preventDefault();
            modal.style.display = "flex";
        };
    });

    var span = document.getElementsByClassName("close_mantenimiento")[0];

    span.onclick = function() {
      modal.style.display = "none";
    };

    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    };
}

// Initial call to attach modal event listeners
attachModalEventListeners();	
	
});

/*Funcion para llenar servicio*/
document.addEventListener('DOMContentLoaded', function () {
  const bigContainer = document.querySelector('.container_servicio');
  const volver = document.querySelector('.breadcrumb_volver');
  const options = document.querySelectorAll('.option_servicio');
  const backToQuestions = document.getElementById('back_to_questions');
  const answerContainer = document.querySelector('.container_answer');
  const answerContent = document.getElementById('answer_content');

  const contents = {
      internet: `
          <div>
              <h3 class="subtitulo_content">Soluciones a dudas sobre Internet</h3>
              <ul class="items_content" style="list-style:none;">
                  <li class="question" data-answer="respuesta1" id="preguntaf1">¿Qué debo hacer si mi módem o router no encienden? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta2" id="preguntaf2">¿Qué hago si no tengo servicio de internet y mi equipo muestra luces intermitentes? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta3" id="preguntaf3">¿Qué debo hacer si no tengo servicio de internet y mi equipo tiene luces fijas? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta4" id="preguntaf4">¿Cómo soluciono la intermitencia en mi servicio de internet <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta5" id="preguntaf5">¿Qué puedo hacer si mi servicio de internet está lento? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
<!-- <li class="question" data-answer="respuesta6" id="preguntaf6">¿Cómo puedo cambiar la contraseña de mi wifi? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li> -->
                    <li class="question" data-answer="respuesta7" id="preguntaf7">¿Qué es una incidencia o daño en el sector? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                    <li class="question" data-answer="respuesta8" id="preguntaf8">¿Puedo suspender temporalmente mi servicio de internet por motivo de vacaciones? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
              </ul>
          </div>`,
      telefonia: `
          <div>
              <h3 class="subtitulo_content">Soluciones a dudas sobre Telefonía</h3>
              <ul class="items_content" style="list-style:none;">
                  <li class="question" data-answer="respuesta9" id="preguntaf9">¿Qué pasos debo seguir si no tengo tono en mi línea telefónica? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta10" id="preguntaf10">¿Qué puedo hacer si mi equipo de telefonía no enciende? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta11" id="preguntaf11">¿Por qué mi teléfono no suena cuando recibo llamadas? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li> 
                  <li class="question" data-answer="respuesta12" id="preguntaf12">¿Por qué hay ruido en mi línea telefónica y cómo puedo solucionarlo? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta13" id="preguntaf13">¿Qué debo hacer si no puedo realizar llamadas a destinos específicos?  <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                   <li class="question" data-answer="respuesta14" id="preguntaf14">¿Como bloquear/desbloquear llamadas? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                    <li class="question" data-answer="respuesta15" id="preguntaf15">¿Puedo suspender temporalmente mi servicio de telefonía por motivo de vacaciones? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
              </ul>
          </div>`,
      tv_streaming: `
          <div>
              <h3 class="subtitulo_content">Soluciones a dudas sobre TV/Streaming</h3>
              <ul class="items_content" style="list-style:none;">
                  <li class="question" data-answer="respuesta16" id="preguntaf16">¿Qué hacer si tu pantalla esta de color negra, azul o roja? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
 <!-- <li class="question" data-answer="respuesta17" id="preguntaf17">¿Como configurar mi control remoto? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li> -->
                  <li class="question" data-answer="respuesta18" id="preguntaf18">¿Se averió mi control remoto necesito uno nuevo? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                  <li class="question" data-answer="respuesta19" id="preguntaf19">¿No tengo audio ni video? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                 <!-- <li class="question" data-answer="respuesta20" id="preguntaf20">¿Qué es Xtrim Play? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>                  
                  <li class="question" data-answer="respuesta21" id="preguntaf21">¿Como recuperar mi contraseña de Xtrim Play? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li> -->
                    <li class="question" data-answer="respuesta22" id="preguntaf22">¿Qué es una incidencia o daño en el sector? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
                    <li class="question" data-answer="respuesta23" id="preguntaf23">¿Como acceder a canales de HD? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
    <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
  </svg></li>
<li class="question" data-answer="respuesta24" id="preguntaf24">¿Puedo suspender temporalmente mi servicio de televisión por motivo de vacaciones? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta25" id="preguntaf25">¿Qué es Zapping? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta26" id="preguntaf26">Si soy cliente xtrim, ¿Cómo puedo contratar los partidos de La Liga Pro Ecuabet? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta27" id="preguntaf27">Si NO soy cliente xtrim, ¿Puedo ver La Liga Pro Ecuabet? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta28" id="preguntaf28">¿En cuántos dispositivos puedo ver al mismo tiempo? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta29" id="preguntaf29">¿Qué canales incluye Zapping? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta30" id="preguntaf30">¿Zapping es un servicio legal? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta31" id="preguntaf31">¿Es segura la plataforma de Zapping? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta32" id="preguntaf32">¿Qué puedo hacer si no tengo un Smart TV compatible? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
<li class="question" data-answer="respuesta33" id="preguntaf33">Quiero cancelar mi servicio Zapping. ¿Cómo lo hago? <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
      <path d="M11.0829 15.0417C11.2679 15.042 11.4472 14.9776 11.5896 14.8596C11.6697 14.7931 11.736 14.7115 11.7846 14.6194C11.8332 14.5273 11.8631 14.4265 11.8726 14.3228C11.8822 14.2191 11.8712 14.1146 11.8403 14.0151C11.8094 13.9157 11.7592 13.8233 11.6925 13.7433L8.14583 9.49999L11.5658 5.24874C11.6316 5.16777 11.6807 5.07459 11.7103 4.97457C11.74 4.87455 11.7495 4.76966 11.7385 4.66593C11.7275 4.5622 11.696 4.46167 11.646 4.37013C11.596 4.27858 11.5284 4.19782 11.4471 4.13249C11.3652 4.06042 11.2692 4.00606 11.1653 3.97282C11.0614 3.93958 10.9518 3.92818 10.8432 3.93933C10.7347 3.95048 10.6296 3.98394 10.5346 4.03762C10.4397 4.09129 10.3568 4.16402 10.2912 4.25124L6.4675 9.00124C6.35106 9.1429 6.28741 9.32058 6.28741 9.50395C6.28741 9.68732 6.35106 9.86501 6.4675 10.0067L10.4258 14.7567C10.5053 14.8525 10.6061 14.9282 10.7203 14.9777C10.8345 15.0272 10.9587 15.0491 11.0829 15.0417Z" fill="#9F62B0" stroke="#9F62B0"/>
    </svg></li>
              </ul>
          </div>`
};

  const answers = {
        respuesta1: `
            <div class="answer" id="respuestaf1">
                <h3 class="subtitulo_content">¿Qué debo hacer si mi módem y/o router no encienden?</h3>
                <p class="items_content">Si tu módem y/o router no encienden sigue los siguientes pasos: </p>
                <p class="items_content">1. Verifica las conexiones.</p>
                <ul class="items_content">
                    <li>Asegúrate de que el <b>módem y/o router</b> estén correctamente conectados a un tomacorriente o fuente de energía.</li>
                </ul>
                <p class="items_content">2. Prueba con otro tomacorriente.</p>
                <ul class="items_content">
                    <li>Si todo está bien conectado y el equipo no aún no enciende, intenta enchufarlo en otro tomacorriente o fuente de energía.</li>
                </ul>
                <!-- <p class="items_content">3. Si el problema persiste.</p>
                <ul class="items_content">
                <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                    <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                </ul> -->
                <p class="items_content">Si el problema persiste y el equipo sigue sin encender, es posible que requieras asistencia técnica. Selecciona tu canal de atención preferido.</p>
                <ul class="items_content">
                    <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                    <li><b>Asesoría telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta2: `
            <div class="answer" id="respuestaf2">
                <h3 class="subtitulo_content">¿Qué hacer si no tienes servicio de internet y tu módem muestra luces intermitentes?</h3>
                <p class="items_content">Si tienes problemas con tu servicio de internet y tu módem muestra luces intermitentes, sigue estos pasos: </p>
                <p class="items_content"><b>1. Revisa el estado de las luces del módem: </b></p>
                <ul class="items_content" style="list-style-type: none;">
                    <li>a. <b>Si tienes un módem marca “Motorola”:</b> Verifica si las luces "SEND" y "RECEIVE" están intermitentes.</li>
                    <li>b. <b>Si tienes un módem marca “Arris”:</b> Verifica si las luces "US" y "DS" están intermitentes.</li>
                    <li>c. <b>Si tienes un módem marca “ZTE”:</b> Revisa si la luz "LOS" está encendida.</li>
                </ul>
                <p class="items_content"><b>2. Reinicia el equipo si las luces están intermitentes:</b></p>
                <p class="items_content">A continuación, te mostramos el procedimiento para reiniciar el módem:</p>
                <ul class="items_content" style="list-style-type: none;">
                    <li><b>a. Desconectar:</b> Desenchufa el módem de la toma eléctrica o fuente de energía.</li>
                    <li><b>b. Esperar:</b> Espera 1 minuto antes de volver a enchufarlo.</li>
                    <li><b>c. Conectar:</b> Enchufa el módem nuevamente a la toma eléctrica o fuente de energía.</li>
                    <li><b>d. Cargar:</b> Espera 2 minutos para que el módem se reinicie completamente y se ajuste a sus niveles correctos de funcionamiento.</li>
                </ul>
                <p class="items_content"><b>3. Revisa nuevamente el estado de las luces del módem:</b></p>
                <ul class="items_content" style="list-style-type: none;">
                    <li>a. <b>Luz de Power:</b> Debe estar fija.</li>
                    <li>b. <b>Luces SEND/RECEIVE o US/DS o LOS:</b> Deben estar fijas para un correcto funcionamiento del servicio.</li>
                </ul>
                   <!-- <p class="items_content">3. Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                   <p class="items_content">3. Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                <p class="items_content">Si posterior a las pruebas, las luces del módem <b>continúan intermitentes y tu servicio no se ha restablecido</b>, es posible que requieras asistencia técnica. Selecciona tu canal de atención preferido:</p>
                <ul class="items_content">
                    <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                    <li><b>Asesoría telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta3: `
            <div class="answer" id="respuestaf3">
                <h3 class="subtitulo_content">¿Qué debo hacer si no tengo servicio de internet y mi módem tiene luces fijas?</h3>
                <p class="items_content">Si no tienes servicio de internet y tu módem tiene luces fijas, sigue estos pasos:</p>
                <p class="items_content">1. <b>Revisa el estado de las luces del módem:</b></p>
                <ul class="items_content" style="list-style-type: none;">
                    <li>a. <b>Si tienes un módem marca “Motorola”:</b> Verifica que las luces "SEND" y "RECEIVE" estén encendidas.</li>
                    <li>b. <b>Si tienes un módem marca “Arris”:</b> Verifica que las luces "US" y "DS" estén encendidas.</li>
                    <li>c. <b>Si tienes un módem marca “ZTE”:</b> Verifica que las luces "PON" e "INTERNET" estén encendidas.</li>
                </ul>
                <p class="items_content">2. <b>Verifica que las luces del módem se mantienen encendidas:</b> Esto indica que el módem está recibiendo señal correctamente. Sin embargo, es probable que el equipo esté <b>inhibido y necesite ser reiniciado.</b></p>
                <p class="items_content">3. <b>Reinicia el equipo módem:</b></p>
                <p class="items_content">A continuación, te mostramos el procedimiento para reiniciar el módem:</p>
                <ul class="items_content" style="list-style-type: none;">
                    <li><b>Procedimiento de reinicio:</b> </li>
                    <li>
                      <ul class="items_content">
                        <li><b>Desconectar:</b> Desenchufa el módem de la toma eléctrica o fuente de energía.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>Esperar:</b> Espera 1 minuto antes de volver a enchufarlo.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>Conectar:</b> Enchufa el módem nuevamente a la toma eléctrica o fuente de energía.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>Cargar:</b> Espera 2 minutos para que el módem se reinicie completamente y se ajuste en sus niveles correctos de funcionamiento.</li>
                      </ul>
                    </li>
                </ul>
                <p class="items_content">4. <b>Verifica el estado del servicio:</b> Si aún no tienes internet, repite el <b>reinicio (paso 3)</b>. En esta ocasión reinicia <b>el módem y el router WIFI</b>.</p>
                
                   <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                   <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                <p class="items_content">Si el problema persiste y continuas sin servicio, es posible que requieras asistencia técnica. Selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                    <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                    <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta4: `
            <div class="answer" id="respuestaf4">
                <h3 class="subtitulo_content">¿Cómo soluciono la intermitencia en mi servicio de internet?</h3>
                <p class="items_content">Si experimentas intermitencia en tu servicio de internet, sigue estos pasos:</p>
                <p class="items_content">1. Revisar la conexión física.</p>
                <ul class="items_content">
                    <li><b>Cableado:</b> Asegúrate de que todos los cables estén bien conectados, tanto el cable de alimentación eléctrica del <b>módem y router</b>, como los cables Ethernet.</li>
                </ul>
                <p class="items_content">2. Revisa la red WIFI:</p>
                <ul class="items_content">
                    <li><b>Ubicación del Router:</b> Coloca el router en un lugar central de tu casa, lejos de objetos que puedan causar interferencias, como microondas, teléfonos inalámbricos, entre otros.</li>
                    <li><b>Ubicación de nuestro dispositivo:</b> Para descartar que el problema sea por la ubicación de tu dispositivo (celular, tablet, laptop, PC), sitúate cerca del router y verifica si la intermitencia continúa o se soluciona.</li>
                    <li><b>Desconectar dispositivos innecesarios:</b> Apaga o desconecta los dispositivos conectados a la red WIFI que no estés utilizando. Estos dispositivos conectados innecesariamente, pueden estar consumiendo el ancho de banda de la red WIFI.</li>
                </ul>
                <p class="items_content">3. Reiniciar dispositivos.</p>
                <ul class="items_content">
                    <li><b>Reiniciar el módem y el router:</b> Desenchufa ambos equipos durante al menos 30 segundos a 1 minuto y luego conéctalos de nuevo.</li>
                    <li><b>Reiniciar dispositivos de conexión:</b> Desconecta y vuelve a conectar los dispositivos que se conectan a la red WIFI (celular, tablet, laptop, PC).</li>
                </ul>
                   <!-- <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                   <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                <p class="items_content">Si el problema persiste y sigues experimentando intermitencia, es posible que requieras asistencia técnica. Selecciona tu canal de atención preferido:</p>
                <ul class="items_content">
                    <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                    <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta5: ` 
            <div class="answer" id="respuestaf5">
                <h3 class="subtitulo_content">¿Qué puedo hacer si mi servicio de internet está lento?</h3>
                <p class="items_content">Si experimentas lentitud en tu servicio de internet, sigue estos pasos:</p>
                <p class="items_content">1. Revisa la red WIFI:</p>
                <ul class="items_content">
                    <li><b>Ubicación del router:</b> Asegúrate de que el router esté en un lugar elevado o central de tu casa, lejos de objetos que puedan causar interferencia, como microondas, teléfonos inalámbricos, entre otros.</li>
                    <li><b>Desconectar dispositivos innecesarios:</b> Apaga o desconecta los dispositivos conectados a la red WIFI que no estés utilizando. Estos dispositivos conectados innecesariamente, pueden estar consumiendo el ancho de banda de la red WIFI.</li>
                </ul>
                <p class="items_content">2. Verifica la lentitud en otros dispositivos:</p>
                <ul class="items_content">
                    <li>Si la lentitud ocurre en <b>todos los dispositivos</b> conectados (celular, laptop, tablets, PC), entonces el problema está en la red interna o en el servicio de internet.</li>
                    <li>Si solo ocurre en <b>un dispositivo</b>, es probable que el inconveniente sea exclusivo de ese dispositivo.</li>
                </ul>
                <p class="items_content">3. Realizar una prueba de velocidad: </p>
                <ul class="items_content">
                    <li><b>Pruebas en red wifi:</b> Desconecta todos los dispositivos de la red, excepto el que usarás para la prueba. Abre tu navegador y accede al medidor de velocidad en http://xtrim.speedtestcustom.com/.</li>
                    <li><b>Pruebas por cable:</b></li>
                    <li style="list-style-type: none;">
                        <ul class="items_content">
                          <li>Desconecta el <b>cable de red (Ethernet)</b> que va desde el módem hacia el router.</li>
                          <li>Conecta el <b>cable de red (Ethernet)</b> directamente al <b>puerto de red</b> de tu laptop o PC.</li>
                          <li>Realiza la prueba de velocidad accediendo al medidor en http://xtrim.speedtestcustom.com/.</li>
                          <li>Una vez finalizada la prueba, vuelve a conectar el <b>cable de red</b> al <b>puerto de red</b> correspondiente del router. </li>
                        </ul>
                    </li>
                </ul>
                <p class="items_content">4. Reiniciar dispositivos.</p>
                <ul class="items_content">
                    <li><b>Reiniciar el módem y el router:</b> Desconéctalos de la corriente durante 30 segundos a 1 minuto y luego vuélvelos a conectar.</li>
                    <li><b>Reiniciar dispositivos de conexión:</b> Reinicia los dispositivos conectados a la red wifi (computadoras, teléfonos, tablets).</li>
                </ul>
                   <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                   <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                <p class="items_content">Si el problema persiste después de seguir estos pasos y no has podido solucionar la lentitud, selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                    <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                    <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta6: `
            <div class="answer" id="respuestaf6">
                <h3 class="subtitulo_content">¿Cómo puedo cambiar la contraseña de mi wifi?</h3>
                   <!-- <p class="items_content">1. <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p> -->
                <p class="items_content">1. <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p>
                <p class="items_content">2. Selecciona la <b>opción 1</b> "Ya soy cliente".</p>
                <p class="items_content">3. Ingresa tu número de <b>Cédula/RUC/Pasaporte.</b></p>
                <p class="items_content">4. Selecciona la cuenta del contrato de internet.</b></p>
                <p class="items_content">5. El Bot mostrará el menú de opciones.</b></p>
                <p class="items_content">6. Selecciona la <b>opción 2</b> "Ayuda con mi Servicio".</b></p>
                <p class="items_content">7. Selecciona la <b>opción 3</b> "Configurar mi wifi". </b></p>
                <p class="items_content">8. Escoge la acción que desea realizar con tu equipo Wifi:</b></p>
                <ul class="items_content">
                    <li><b>Opción 1</b> - Cambio de Contraseña</li>
                    <li><b>Opción 2</b> - Cambiar nombre de mi red Wifi.</li>
                </ul>
                <p class="items_content">9. Siguiendo estos pasos deberías haber podido cambiar la contraseña de tu red Wifi. </p>
            </div>`,
        respuesta7: `
            <div class="answer" id="respuestaf7">
                <h3 class="subtitulo_content">¿Qué es una incidencia o daño en el sector?</h3>
                <p class="items_content">Un incidente o daño del sector es cualquier evento inesperado que puede provocar una interrupción en el servicio.</p>
            </div>`,
	    respuesta8: `
            <div class="answer" id="respuestaf8">
                  <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de internet por motivo de vacaciones? </h3>
                  <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                  <p class="items_content"><b>Requisitos: </b></p>
                  <ul class="items_content">
                      <li>Es importante que los pagos del servicio estén al día previo a realizar la solicitud antes de la fecha de vencimiento de la factura.</li>
                      <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                      <li>Al finalizar el periodo de suspensión temporal, el contrato se reactivará de manera automática.</li>
                      <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                   <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                   <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                  </ul>
                 <p class="items_content>Gestiona esta solicitud en el canal de atención de tu preferencia:</p>
                      <li style="list-style-type: none;">
                            <ul class="items_content">
                                <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                                <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                            </ul>
                       </li>
              </div>`,
        respuesta9: `
            <div class="answer" id="respuestaf9">
                <h3 class="subtitulo_content">¿Qué pasos debo seguir si no tengo tono en mi línea telefónica?</h3>
                <p class="items_content">Si no tienes tono en tu línea telefónica, sigue estos pasos: </p>
                <p class="items_content">1. <b>Revisa el módem de telefonía:</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que el módem <b>(ARRIS o ZTE)</b> de telefonía se encuentre conectado al tomacorriente y que sus luces estén encendidas.</li>
                </ul>
                <p class="items_content">2. <b>Verifica las conexiones.</b></p>
                <ul class="items_content">
                    <li>Comprueba que los cables estén bien conectados entre el módem de telefonía (ARRIS o ZTE) y la base del teléfono.</li>
                </ul>
                <p class="items_content">3. <b>Reinicia el equipo.</b></p>
                <ul class="items_content">
                    <li><b>Desconectar:</b> Desenchufa el módem de telefonía de la toma eléctrica o fuente de energía.</li>
                    <li><b>Esperar:</b> Deja pasar 1 minuto antes de volver a enchufarlo.</li>
                    <li><b>Conectar:</b> Enchufa el módem de telefonía nuevamente a la toma eléctrica o fuente de energía.</li>
                    <li><b>Cargar:</b> Espera unos 2 minutos para que el módem se reinicie completamente y se ajuste a sus niveles correctos de funcionamiento.</li>
                </ul>
                <p class="items_content">4. <b>Prueba el servicio:</b></p>
                <ul class="items_content">
                    <li>Verifica si el tono de la línea se ha restablecido.</li>
                </ul>
                   <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                   <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                <p class="items_content">Si el problema persiste después de estos pasos y no tienes tono en tu línea, selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                                <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                                <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta10: `
            <div class="answer" id="respuestaf10">
                <h3 class="subtitulo_content">¿Qué puedo hacer si mi módem de telefonía no enciende?</h3>
                <p class="items_content">Si tu módem de telefonía no enciende, sigue estos pasos:</p>
                <p class="items_content">1. <b>Verifica las conexiones.</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que el módem de telefonía (ARRIS o ZTE) esté correctamente conectado a un tomacorriente o fuente de energía.</li>
                </ul>
                <p class="items_content">2. <b>Prueba con otro tomacorriente:</b></p>
                <ul class="items_content">
                    <li>Si todo está bien conectado pero el equipo aún no enciende, prueba enchufarlo en otro tomacorriente para descartar un problema con la fuente de energía.</li>
                </ul>
                <!-- <p class="items_content">3. <b>Si el problema persiste.</b></p>
                <ul class="items_content">
                    <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                    <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                </ul> -->
                <p class="items_content">Si el problema persiste después de estos pasos y no tienes tono en tu línea, selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                        <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                        <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta11: `
            <div class="answer" id="respuestaf11">
                <h3 class="subtitulo_content">¿Por qué mi teléfono no suena cuando recibo llamadas?</h3>
                <p class="items_content">Si tu teléfono no suena al recibir llamadas, sigue estos pasos:</p>
                <p class="items_content">1. <b>Revisa que el módem de telefonía esté encendido.</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que las luces del módem (ARRIS o ZTE) estén encendidas correctamente.</li>
                </ul>
                <p class="items_content">2. <b>Verifica las conexiones.</b></p>
                <ul class="items_content">
                    <li>Comprueba que los cables estén bien conectados entre el módem de telefonía (ARRIS o ZTE) y la base del teléfono.</li>
                </ul>
                <p class="items_content">3. <b>Verifica el volumen del timbre.</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que el volumen del timbre del teléfono o de la base telefónica esté configurado adecuadamente.</li>
                </ul>
                <p class="items_content">4. <b>Prueba con otro teléfono:</b></p>
                <ul class="items_content">
                    <li>Si es posible, conecta otro teléfono o base telefónica para comprobar si el problema persiste.</li>
                </ul>
                <p class="items_content">Si el problema persiste después de estos pasos y tu teléfono no suena al recibir llamadas, selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                        <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                        <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta12: `
            <div class="answer" id="respuestaf12">
                <h3 class="subtitulo_content">¿Por qué hay ruido en mi línea telefónica y cómo puedo solucionarlo?</h3>
                <p class="items_content">Si escuchas ruido en tu línea telefónica, sigue estos pasos:</p>
                <p class="items_content">1. <b>Verifica las conexiones.</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que los cables entre el módem de telefonía (ARRIS o ZTE) y la base del teléfono estén bien conectados. Revisa que los cables no estén en mal estado, torcidos, cortados o desgastados.</li>
                </ul>
                <p class="items_content">2. <b>Reinicia el módem de telefonía:</b></p>
                <ul class="items_content">
                    <li><b>Desconectar:</b> Desenchufa el módem de telefonía de la toma eléctrica o fuente de energía.</li>
                    <li><b>Esperar:</b> Deja pasar 1 minuto antes de volver a enchufarlo.</li>
                    <li><b>Conectar:</b> Enchufa el módem de telefonía nuevamente a la toma eléctrica o fuente de energía.</li>
                    <li><b>Cargar:</b> Espera unos 2 minutos para que el módem se reinicie completamente y se ajuste a sus niveles correctos de funcionamiento.</li>
                </ul>
                <p class="items_content">3. <b>Prueba el servicio:</b></p>
                <ul class="items_content">
                    <li>Realiza una llamada para verificar si el ruido en la línea ha desaparecido.</li>
                </ul>
            </div>`,
        respuesta13: `
            <div class="answer" id="respuestaf13">
                <h3 class="subtitulo_content">¿Qué debo hacer si no puedo realizar llamadas a destinos específicos?</h3>
                <p class="items_content">1. <b>Verifica el número que este correcto.</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que el número al que intentas llamar tiene la cantidad correcta de dígitos.</li>
                </ul>
                <p class="items_content">2. <b>Revisa que el prefijo sea el correcto.</b></p>
                <ul class="items_content" style="list-style-type: none;">
                    <li>Para llamadas nacionales los prefijos provinciales son los siguientes: </li>
                    <li>
                      <ul class="items_content">
                        <li><b>02:</b> Pichincha, Sto. Domingo.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>03:</b> Bolívar, Chimborazo, Cotopaxi, Tungurahua, Pastaza.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>04:</b> Guayas, Santa Elena.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>05:</b> Galápagos, Los Ríos, Manabí.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>06:</b> Carchi, Esmeraldas, Imbabura, Napo, Orellana, Sucumbíos.</li>
                      </ul>
                    </li>
                    <li>
                      <ul class="items_content">
                        <li><b>07:</b> Azuay, Cañar, El Oro, Loja, Morona, Zamora.</li>
                      </ul>
                    </li>
                </ul>
                <p class="items_content">3. <b>Valida el código de país y el código de área:</b></p>
                <p class="items_content">Para el caso de llamadas internacionales revisa el siguiente ejemplo:</p>
                <ul class="items_content">
                    <li>Para llamar a Ecuador: <b>Código de País</b> (593) + <b>Código de Área Guayas</b> (4) + <b>Número local</b> (6002400).</li>
                </ul>
                <p class="items_content">4. <b>Realiza una llamada de prueba.</b></p>
                <ul class="items_content">
                    <li>Posterior a la revisión de los puntos anteriores, podrías intentar realizar la llamada nuevamente.</li>
                </ul>
            </div>`,
        respuesta14: `
            <div class="answer" id="respuestaf14">
                <h3 class="subtitulo_content">¿Cómo bloquear/desbloquear llamadas?</h3>
                <p class="items_content">Para bloquear o desbloquear llamadas desde tu línea telefónica, sigue estos pasos:</p>
                <p class="items_content">1. <b>Bloqueo/Desbloqueo temporal o variable:</b></p>
                <ul class="items_content">
                    <li>Marca la combinación: <b>*20 + PIN + * + número de teléfono</b> (celular, internacional o nacional) que deseas bloquear o desbloquear.</li>
                </ul>
                <p class="items_content">2. <b>Bloqueo/Desbloqueo prolongado:</b></p>
                <ul class="items_content">
                    <li>Marca <b>*33#</b> desde tu teléfono.</li>
                    <li>Selecciona una de las siguientes opciones:</li>
                    <li style="list-style-type: none;">
                            <ul class="items_content">
                                <li><b>Opción 1: </b>Bloquear o desbloquear llamadas.</li>
                                <li><b>Opción 2: </b>Cambiar el PIN de seguridad.</li>
                            </ul>
                    </li>
                </ul>
            </div>`,
	    respuesta15: `
              <div class="answer" id="respuestaf15">
                  <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de telefonía por motivo de vacaciones? </h3>
                  <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                  <p class="items_content"><b>Requisitos: </b></p>
                  <ul class="items_content">
                      <li>Es importante que los pagos del servicio estén al día antes de realizar la solicitud.</li>
                      <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                      <li>Al finalizar el periodo de suspensión temporal, el contrato se reactivará de manera automática.</li>
                      <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                      <li>Se aplican costos de la tarifa básica de telefonía.</b></li>
                   <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                   <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                  </ul>
                  <p class="items_content">Gestiona tu solicitud en el canal de atención de tu preferencia: </p>
                   <ul class="items_content">
                            <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                            <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                   </ul>
              </div>`,
        respuesta16: `
            <div class="answer" id="respuestaf16">
                <h3 class="subtitulo_content">¿Qué hacer si tu pantalla esta de color negra, azul o roja?</h3>
                <p class="items_content">1. <b>Verifica las conexiones entre tu decodificador y tu TV.</b></p>
                <ul class="items_content">
                    <li>Comprueba que los cables estén bien conectados y ajustados.</li>
					<li>Revisa que los cables se encuentran en buen estado descartando que estén torcidos, cortados, desgastados.</li>
                </ul>
                <p class="items_content">2. <b>Reinicia el equipo decodificador.</b></p>
                <ul class="items_content">
                    <li><b>Desconectar:</b> Desconecta el decodificador de la toma eléctrica o fuente de energía.</li>
                    <li><b>Esperar:</b> Espera 1 minuto antes de volver a conectarlo.</li>
                    <li><b>Conectar:</b> Vuelve a conectar el equipo a la toma eléctrica o fuente de energía.</li>
                    <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos antes de probar el servicio.</li>
                </ul>
                   <!-- <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                   <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                <p class="items_content">Si el problema persiste después de estos pasos y no tienes tono en tu línea, selecciona tu canal de atención preferido: </p>
                <ul class="items_content">
                        <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                        <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta17: `
            <div class="answer" id="respuestaf17">
                <h3 class="subtitulo_content">¿Cómo configurar mi control remoto?</h3>
                   <!-- <p class="items_content">1. <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p> -->
                <p class="items_content">1. <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p>
                <p class="items_content">2. Selecciona la <b>opción 1</b> "Ya soy cliente".</p>
                <p class="items_content">3. Ingresa tu número de <b>Cédula/RUC/Pasaporte.</b></p>
                <p class="items_content">4. Selecciona la cuenta del contrato donde tengas el servicio de televisión.</b></p>
                <p class="items_content">5. El Bot mostrará el menú de opciones.</b></p>
                <p class="items_content">6. Selecciona la <b>opción 7</b> "Instructivos".</b></p>
                <p class="items_content">7. Selecciona la <b>opción 3</b> "Control remoto". </b></p>
                <p class="items_content">8. Sigue los pasos del instructivo para que puedas configurar tu control remoto.</b></p>
            </div>`,
        respuesta18: `
            <div class="answer" id="respuestaf18">
                <h3 class="subtitulo_content">¿Se averió mi control remoto necesito uno nuevo?</h3>
                <p class="items_content">Si tu control remoto no funciona, sigue estos pasos:</p>
                <p class="items_content">1. <b>Reemplaza las baterías.</b></p>
                <ul class="items_content">
                        <li>Prueba cambiando las baterías de tu control remoto por unas nuevas, para descartar que se hayan desgastado.</li>
                </ul>
                <p class="items_content">2. <b>Revisa el estado de tu control.</b></p>
                <ul class="items_content">
                        <li>Verifica que no tengas rotas o desgastadas.</li>
                </ul>
                <!-- <p class="items_content">3. Para adquirir un control nuevo puedes ingresar <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/compra-tv-box" target="_blank" title="TV Box/Control Remoto">aquí</a>.</p> -->
                <p class="items_content">Si al seguir los pasos anteriores y al pulsar las teclas del control remoto no se enciende ninguna luz, es posible que el control remoto esté dañado y necesites reemplazarlo por uno nuevo. Para obtener uno, selecciona la agencia más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</p>
            </div>`,
        respuesta19: `
            <div class="answer" id="respuestaf19">
                <h3 class="subtitulo_content">¿No tengo audio ni video?</h3>
                <p class="items_content">Si no tienes audio ni video en tu TV, sigue estos pasos:</p>
                <p class="items_content">1. <b>Verifica las conexiones entre tu decodificador y la TV:</b></p>
                <ul class="items_content">
                    <li>Asegúrate de que los cables estén bien conectados y ajustados.</li>
                    <li>Revisa que los cables no estén torcidos, cortados o desgastados.</li>
                </ul>
                <p class="items_content">2. <b>Reinicia el decodificador:</b></p>
                <ul class="items_content">
                    <li><b>Desconectar:</b> Desenchufa el decodificador de la toma eléctrica.</li>
                    <li><b>Esperar:</b> Deja pasar 1 minuto.</li>
                    <li><b>Conectar:</b> Vuelve a enchufarlo.</li>
                    <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste correctamente.</li>
                </ul>
                    <!-- <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                    <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                <p class="items_content">3. <b>Si el problema persiste, selecciona tu canal de atención preferido:</b></p>
                <ul class="items_content">
                        <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                        <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                </ul>
            </div>`,
        respuesta20: `
            <div class="answer" id="respuestaf20">
                <h3 class="subtitulo_content">¿Qué es Xtrim Play?</h3>
                <p class="items_content">Es una plataforma de entretenimiento de Xtrim, donde encontrarás canales en vivo, series, películas, deportes y más, todo en HD y accesible desde cualquier dispositivo, en cualquier momento.
                </p>
            </div>`,
        respuesta21: `
            <div class="answer" id="respuestaf21">
                <h3 class="subtitulo_content">¿Cómo recuperar mi contraseña de Xtrim Play?</h3>
                   <!-- <p class="items_content">1. Puedes recuperar tu contraseña de Xtrim Play <a href="https://autoservicio.xtrim.com.ec/autenticacion/olvido-clave " target="_blank" title="Xtrim Play">aquí</a>.</p> -->
                <p class="items_content">1. Puedes recuperar tu contraseña de Xtrim Play <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Xtrim Play">aquí</a>.</p>
            </div>`,
        respuesta22: `
            <div class="answer" id="respuestaf22">
                <h3 class="subtitulo_content">¿Qué es una incidencia o daño en el sector?</h3>
                <p class="items_content">Un incidente o daño del sector es cualquier evento inesperado que puede provocar una interrupción en el servicio.</p>
            </div>`,
        respuesta23: `
            <div class="answer" id="respuestaf23">
                <h3 class="subtitulo_content">¿Cómo acceder a canales de HD?</h3>
                <p class="items_content">1. Cambiarse de plan o solicitar el paquete de canales en HD.</p>
                <p class="items_content">2. Comunicarse para asesoría telefoníca al <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">"Call Center"</a>.</p>
            </div>`,
        respuesta24: `
              <div class="answer" id="respuestaf24">
                  <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de televisión por motivo de vacaciones? </h3>
                  <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                  <p class="items_content"><b>Requisitos: </b></p>
                  <ul class="items_content">
                      <li>Es importante que los pagos del servicio estén al día antes de realizar la solicitud.</li>
                      <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                      <li>Al finalizar el período de suspensión temporal, el contrato se reactivará de manera automática.</li>
                      <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                   <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                   <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                  </ul>
                  <p class="items_content">Gestiona esta solicitud en el canal de atención de tu preferencia:</p>
                   <li style="list-style-type: none;">
                        <ul class="items_content">
                        <li><b>Atención presencial: </b>Visita una de nuestras agencias y recibe atención personalizada. Encuentra la más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                        <li><b>Atención telefónica: </b>Si prefieres hablar con un asesor de servicio al cliente, comunícate con nuestro Call Center <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                        </ul>
                    </li>
              </div>`,    
          respuesta25: `
              <div class="answer" id="respuestaf25">
                  <h3 class="subtitulo_content">¿Qué es Zapping?</h3>
                  <p class="items_content">Zapping es una plataforma de entretenimiento Streaming donde podrás ver todos los partidos en directa de la Liga Pro Ecuabet y programación en vivo.</p>
              </div>`,    
          respuesta26: `
                  <div class="answer" id="respuestaf26">
                      <h3 class="subtitulo_content">Si soy cliente xtrim, ¿Cómo puedo contratar los partidos de La Liga Pro Ecuabet?</h3>
                      <ul class="items_content">
                          <li><b>Si eres cliente de TV residencial</b>, tienes totalmente gratis durante el 2024 Zapping Sports en el canal 220 SD y 751 HD.</li>
                          <li><b>Si eres cliente de internet</b>, activa Zapping agregándolo a tu plan de internet. El valor de Zapping se sumará a tu facturación mensual. Puedes activar el servicio de Zapping <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</li>
                      </ul>
                  </div>`,
          respuesta27: `
                  <div class="answer" id="respuestaf27">
                      <h3 class="subtitulo_content">Si NO soy cliente xtrim, ¿Puedo ver La Liga Pro Ecuabet?</h3>
                      <p class="items_content">¡Claro que sí!</p>
                      <p class="items_content">Puedes ver la Liga Pro Ecuabet de las siguientes maneras:</p>
                      <ul class="items_content">
                          <li>Contratando el plan X-Futbol que incluye internet de 300*megas + Zapping. <a href="https://wa.me/593968600400" target="_blank" rel="noopener">Contrata Ahora</a>.</li>
                          <li>Suscribiéndote a Zapping con tu tarjeta bancaria por $5,99 al mes. Puedes hacerlo desde <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</li>
                      </ul>
                  </div>`,
          respuesta28: `
                  <div class="answer" id="respuestaf28">
                      <h3 class="subtitulo_content">¿En cuántos dispositivos puedo ver al mismo tiempo?</h3>
                      <p class="items_content">Disfruta todo el contenido de Zapping en 5 dispositivos a la vez: 4 conectados a tu red principal y 1 en otra red. Para más detalles, revisa la guía de control de dispositivos <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</p>
                  </div>`,
	      respuesta29: `
                  <div class="answer" id="respuestaf29">
                      <h3 class="subtitulo_content">¿Qué canales incluye Zapping?</h3>
                      <p class="items_content">Con Zapping tienes +45 canales, incluye programación nacional e internacional y <b>la Liga Pro Ecuabet Serie A*</b> y <b>Serie B**</b> en exclusiva.</p>
            <div class="channel-container">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/Zapping-ver_.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ECDF-ver_.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ecuavisa.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/Teleamazonas.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/TC.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/rts.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/gamavision.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telerama.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ecuadorTV.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/TVC.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/uno.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/wuan.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/24-7.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telepremier.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/vitoTV.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/oromar.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/redonda.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/scandalo.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/DW.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/VOA.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/enlace.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/france24.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telefe.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/cgtn.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/caracol-television.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/canal26.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/bloomberg.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/bbc-news.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/antena3.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/amc.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/all-jazeera.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/allegro.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/24h.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/tvchile.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/rt.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/rcn-nuestratele.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/rai-italia.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/maschic.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/kanalddrama.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/inti-network.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/gourmet.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/fox-news.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/filmandarts.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/ewtn.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/eurochannel.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/europa.jpg" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/tve.png" class="channel">
                <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/11/tvmonde.png" class="channel">
            </div>
                  </div>`,
          respuesta30: `
                  <div class="answer" id="respuestaf30">
                      <h3 class="subtitulo_content">¿Zapping es un servicio legal?</h3>
                      <p class="items_content">Sí, Zapping es una plataforma de contenido legal asegurando la autorización de todo el contenido transmitido.</p>
                  </div>`,
          respuesta31: `
                  <div class="answer" id="respuestaf31">
                      <h3 class="subtitulo_content">¿Es segura la plataforma de Zapping?</h3>
                      <p class="items_content">¡Por supuesto! Zapping garantiza la seguridad de tus datos y transacciones, sin almacenar la información de tus medios de pago.</p>
                  </div>`,
          respuesta32: `
                  <div class="answer" id="respuestaf32">
                      <h3 class="subtitulo_content">¿Qué puedo hacer si no tengo un Smart TV compatible?</h3>
                      <p class="items_content">Te recomendamos que utilices uno de los dispositivos compatibles para ver Zapping, conócelos <a href="https://www.zapping.ec/compatibilidad" target="_blank" rel="noopener">aquí</a>.</p>
                  </div>`,
          respuesta33: `
                  <div class="answer" id="respuestaf33">
                      <h3 class="subtitulo_content">Quiero cancelar mi servicio Zapping. ¿Cómo lo hago?</h3>
                      <ul class="items_content">
                          <li><b>Si eres cliente de Xtrim y activaste Zapping en tu plan de internet:</b> Puedes hacerlo llamando al 600 4000 antes del 23 del mes para evitar que se cobre en tu próxima factura. Una vez que solicites la cancelación, tu servicio seguirá activo hasta el final del mes. Recuerda que debes tener Zapping activo por al menos 30 días.</li>
                          <li><b>Si contrataste Zapping en <a href="https://www.zapping.ec/compatibilidad" target="_blank" rel="noopener">www.zapping.ec</a>:</b> Puedes desactivarlo directamente en la app, y tu servicio se dará de baja de inmediato.</li>
                      </ul>
                  </div>`
  };

function updateContent(contentKey) {
    return contents[contentKey];
}

function showLoader() {
    return `<div class="loader"></div>`;
}

function toggleAnswer(question) {
    const answerKey = question.getAttribute('data-answer');
    const answerElement = question.nextElementSibling;

    if (question.classList.contains('active')) {
        answerElement.remove();
        question.classList.remove('active');
        return;
    }

    const allAnswers = document.querySelectorAll('.answer');
    allAnswers.forEach(answer => {
        if (answer !== answerElement) {
            answer.previousElementSibling.classList.remove('active');
            answer.remove();
        }
    });

    const answerDiv = document.createElement('div');
    answerDiv.className = 'answer';
    answerDiv.innerHTML = answers[answerKey];
    question.insertAdjacentElement('afterend', answerDiv);
    question.classList.add('active');

    // Adjuntar eventos para los modales
    attachModalEventListeners();
}

/*Hash por default en el primer item Servicio*/
window.addEventListener('load', function() {
    const path = window.location.pathname;

    if (path.endsWith('/centro-de-ayuda/servicios/') && !location.hash) {
        location.replace(`${path}#internet`);
    } else if (path.endsWith('/centro-de-ayuda/facturacion-y-pagos/') && !location.hash) {
        location.replace(`${path}#contenido1f`);
    } else if (path.endsWith('/centro-de-ayuda/solicitudes/') && !location.hash) {
        location.replace(`${path}#contenido1`);
    }
});
	
options.forEach(option => {
    option.addEventListener('click', function () {
        const contentKey = option.getAttribute('data-content');
        options.forEach(opt => opt.classList.remove('selected', 'active'));
        option.classList.add(window.innerWidth <= 768 ? 'active' : 'selected');

        if (window.innerWidth <= 768) { // Mobile view
            const nextElement = option.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_servicio')) {
                nextElement.remove();
            } else {
                option.insertAdjacentHTML('afterend', `<div class="content_servicio">${updateContent(contentKey)}</div>`);
            }

            // Agregar event listener para mostrar la respuesta cuando se haga clic en una pregunta
            const questions = document.querySelectorAll('.question');
            questions.forEach(question => {
                question.addEventListener('click', function () {
                    const answerKey = question.getAttribute('data-answer');
                    showAnswer(answerKey);
                    // Modifica el historial del navegador para reflejar la respuesta mostrada
                    history.pushState(null, null, `#answer-${answerKey}`);
                });
            });

            // Adjuntar eventos para los modales
            attachModalEventListeners();
        } else { // Desktop view
            const contentDiv = document.getElementById('content_servicio');
            contentDiv.innerHTML = updateContent(contentKey);
            history.pushState(null, null, `#/centro-de-ayuda/servicios/${contentKey}`);

            const questions = document.querySelectorAll('.question');
            questions.forEach(question => {
                question.addEventListener('click', function () {
                    toggleAnswer(question);
                    const questionId = question.id;
                    history.pushState(null, null, `#${contentKey}-${questionId}`);
                });
            });

            // Adjuntar eventos para los modales
            attachModalEventListeners();
        }
    });
});

function showAnswer(answerKey) {
    bigContainer.style.display = 'none';
    volver.style.display = 'none';
    answerContainer.style.display = 'block';
    answerContent.innerHTML = showLoader();
    setTimeout(() => {
        answerContent.innerHTML = answers[answerKey];

        // Adjuntar eventos para los modales
        attachModalEventListeners();
    }, 1000);
}

function handleNavigation() {
    if (location.hash.startsWith('#answer-')) {
        const answerKey = location.hash.replace('#answer-', '');
        showAnswer(answerKey);
    } else {
        const hash = location.hash.substring(1);
        const [sectionId, questionId] = hash.split('-');
        const section = document.querySelector(`.option_servicio[data-content="${sectionId}"]`);
        if (section) {
            options.forEach(opt => opt.classList.remove('selected'));
            section.classList.add('selected');
            const contentKey = section.getAttribute('data-content');
            const contentDiv = document.getElementById('content_servicio');
            contentDiv.innerHTML = updateContent(contentKey);

            // Adjuntar eventos para los modales
            attachModalEventListeners();

            // Asegurar que las preguntas en la nueva sección tengan event listeners
            const questions = document.querySelectorAll('.question');
            questions.forEach(question => {
                question.addEventListener('click', function () {
                    toggleAnswer(question);
                });
            });

            // Si hay un questionId, mostrar la respuesta correspondiente
            if (questionId) {
                const question = document.getElementById(questionId);
                if (question) {
                    toggleAnswer(question);
                }
            }
        }
    }
}

if (window.innerWidth > 768) {
    const firstSelected = document.querySelector('.option_servicio.selected');
    if (firstSelected) {
        firstSelected.click();
    }
}

function handleScreenSizeChange() {
    const mobileMediaQuery = window.matchMedia('(max-width: 768px)');
    if (mobileMediaQuery.matches) {
        options.forEach(opt => opt.classList.remove('selected'));
    } else {
        options.forEach(opt => {
            const nextElement = opt.nextElementSibling;
            if (nextElement && nextElement.classList.contains('content_servicio')) {
                nextElement.remove();
            }
        });
    }
}

// Evento para el breadcrumb "<volver" en mobile
backToQuestions.addEventListener('click', function () {
    history.back();
});
	
handleScreenSizeChange();
window.addEventListener('resize', handleScreenSizeChange);
window.addEventListener('popstate', handleNavigation);
handleNavigation();
	
/*Modal mantenimiento*/
// Function to attach modal event listeners
function attachModalEventListeners() {
    var modal = document.getElementById("myModal_mantenimiento");

    var openModalElements = document.querySelectorAll('.open-modal_mantenimiento');

    openModalElements.forEach(function(element) {
        element.onclick = function(event) {
            event.preventDefault();
            modal.style.display = "flex";
        };
    });

    var span = document.getElementsByClassName("close_mantenimiento")[0];

    span.onclick = function() {
      modal.style.display = "none";
    };

    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    };
}

// Initial call to attach modal event listeners
attachModalEventListeners();
		
	
});

/*Prueba con el buscador UX*/
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('help-center-search');
    const resultsContainer = document.getElementById('search-results');

    // Contenido cargado dinámicamente
    const contents = {
        contenido1: `
            <div>
                <h3 class="subtitulo_content">¿Cómo realizo un cambio de forma de pago?</h3>
                <ul class="items_content">
                    <li>Los pagos del servicio deben estar al día antes de solicitar el cambio.</li>
                    <li>La cuenta o tarjeta de crédito debe pertenecer al titular del contrato.</li>
                    <li>La cuenta o tarjeta de crédito deberá encontrarse activa.</li>
                    <li>El formulario de autorización de débito bancario debe estar firmado por el titular del contrato.</li>
                    <li>Este trámite lo puede realizar desde cualquier canal presencial o digital de autoservicio Xtrim.</li>
                </ul>
            </div>`,
            contenido2: `
            <div>
                <h3 class="subtitulo_content">¿Cómo realizo un cambio de titular?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de realizar el cambio de titular.</li>
                    <li>Cédula de identidad del actual titular, cédula de identidad del nuevo titular.</li>
                    <li>Adjuntar Formulario de cambio de titular debidamente completado y firmado por el titular actual y nuevo titular.</li>
                    <li>En caso de registrar un débito bancario, el nuevo titular debe descargar el formulario de autorización correspondiente y firmarlo.</li>
                    <li>Este trámite lo puede realizar desde cualquier canal presencial o digital de autoservicio Xtrim.</li>
  <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/cambio-titular" target="_blank" title="Cambio de Titular">aquí</a>.</li> -->
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Cambio de Titular">aquí</a>.</li>
  
  <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
            </div>`,
        contenido3: `
            <div>
                <h3 class="subtitulo_content">¿Cómo solicito mi convenio de pago?</h3>
                <ul class="items_content">
                    <li>No deberás contar con un convenio activo.</li>
                    <li>Esta oferta es válida para clientes con una antigüedad superior a 6 meses y un saldo adeudado de al menos $50.</li>
                    <li>La deuda puede diferirse en cuotas de 3, 4, o 6 meses.</li>
                    <li>Una vez que solicites el convenio, la primera cuota estará activa de inmediato. Las siguientes cuotas se añadirán a tus facturas mensuales emitidas posteriormente.</li>
                    <li>En caso de incumplir con los pagos requeridos y caer en mora, el convenio no será eliminado y no se permitirá acceder a uno nuevo.</li>
  <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/convenio-pago" target="_blank" title="Convenio de Pago">aquí</a>.</li> -->
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Convenio de Pago">aquí</a>.</li>
  
  <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
            </div>`,
        contenido4: `
            <div>
                <h3 class="subtitulo_content">¿Quieres reubicar tus equipos a una nueva dirección?</h3>
                <ul class="items_content">
                    <li>Lleva tus equipos a tu nueva dirección.</li>
                    <li>Nuestros técnicos se encargarán de la instalación.</li>
                    <li>Precio de instalación para Conexión Híbrida: $17.86 + impuestos</li>
                    <li>Precio de instalación para Fibra Óptica: $35 + impuestos</li>
  <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/cambio-direccion" target="_blank" title="Cambio de Dirección">aquí</a>.</li> -->
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Cambio de Dirección">aquí</a>.</li>
  
  <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
            </div>`,
        contenido5: `
            <div>
                <h3 class="subtitulo_content">¿Cómo solicito mi beneficio por discapacidad?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de solicitar el beneficio.</li>
                    <li>Cédula actualizada con información de discapacidad.</li>
                    <li>Planilla de servicios básicos del lugar de instalación del servicio, en caso de no ser vivienda propia el Contrato de arrendamiento notariado a nombre del titular o cónyuge.</li>
  <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/beneficios-discapacidad" target="_blank" title="Beneficio Discapacidad">aquí</a>.</li> -->
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Beneficio Discapacidad">aquí</a>.</li>
  
  <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
            </div>`,
        contenido6: `
            <div>
                <h3 class="subtitulo_content">¿Cómo solicito mi beneficio como 3era. Edad?</h3>
                <ul class="items_content">
                    <li>Es importante que los pagos del servicio estén al día antes de solicitar el beneficio.</li>
                    <li>El titular del contrato debe haber cumplido 65 años.</li>
                    <li>Cédula/pasaporte del titular del contrato.</li>
                    <li>Planilla de servicios básicos del lugar de instalación del servicio, en caso de no ser vivienda propia el Contrato de arrendamiento notariado a nombre del titular o cónyuge.</li>
                    <li>Adjuntar formulario de beneficios de tercera edad.</li>
  <!-- <li>Gestiona este trámite <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/beneficios-3ra-edad" target="_blank" title="Beneficio 3era Edad">aquí</a>.</li> -->
                    <li>Gestiona este trámite <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Beneficio 3era Edad">aquí</a>.</li>
  
  <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                </ul>
            </div>`,
        facturas1f: `
            <div>
                <h3 class="subtitulo_content">¿Qué es Historial de Facturas?</h3>
                <p class="items_content">Es un registro de todas las facturas que has recibido por tu(s) servicio(s) Xtrim.</p>
    <!-- <p class="items_content">Puedes revisar el historial y detalles de tus facturas desde nuestros canales digitales <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">Mi Xtrim App</a> y <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> -->
                <p class="items_content">Puedes revisar el historial y detalles de tus facturas desde nuestros canales digitales <a class="open-modal_mantenimiento" style="cursor:pointer;" title="App Mi Xtrim">Mi Xtrim App</a> y <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>
                <p class="items_content">Si deseas revisar tus últimas seis facturas, puedes hacerlo fácilmente desde Mi Xtrim Web:</p>
                <ul class="items_content">
    <!-- <li>Inicia sesión en <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</li> -->
                    <li>Inicia sesión en <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</li>
                    <li>Una vez dentro, dirígete a la opción <b>"Historial de factura"</b>.</li>
                    <li>Si tienes más de una cuenta, identifica una para visualizar el historial.</li>
                    <li>Selecciona la factura que deseas revisar y presiona el botón <b>"Descargar"</b> para ver los detalles.</li>
                </ul>
            </div>`, 
         facturas2f: `
              <div>
                  <h3 class="subtitulo_content">¿Dónde puedo consultar mi saldo?</h3>
                  <p class="items_content">Puedes revisarlo en nuestra portal y app de autoservicio Mi Xtrim ingresando con tu usuario y contraseña, o escribiendo en WhatsApp a nuestro Chatbot al 0968600400.</p>
                  <ul class="items_content">
                      <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                      <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
    <!-- <li>Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a>.</li> -->
                      <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
                      <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
    <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                  </ul>
              </div>`,
          facturas3f: `
              <div>
                  <h3 class="subtitulo_content">¿Dónde puedo revisar mi historial de facturas?</h3>
                  <p class="items_content">Puedes revisarlo en nuestra portal y app de autoservicio Mi Xtrim ingresando con tu usuario y contraseña.</p>
                  <ul class="items_content">
                  <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                      <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                      <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
    <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                  </ul>
              </div>`,
          facturas4f: `
              <div>
                  <h3 class="subtitulo_content">¿Dónde puedo realizar mis pagos?</h3>
                  <p class="items_content">Puedes realizar tus pagos sin filas con tus tarjetas bancarias, a través de nuestra web y app de autoservicio <b>Mi Xtrim</b> ingresando con tu usuario y contraseña, escribiendo en WhatsApp a nuestro <b>Chatbot</b> al 0968600400, o en nuestros Kioskos.</p>
                  <ul class="items_content">
                      <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                      <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                      <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
                      <li>Ver <a href="https://www.xtrim.com.ec/kioscos/" target="_blank" title="Kioscos">Kioscos</a>.</li>
                      <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
    <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                  </ul>
                  <p class="items_content">Si tu forma de pago es Efectivo, puedes pagar a través de ventanillas bancarias, Banco del Barrio, Mi Vecino, Western Union, o Red de Servicios Facilito.</p>
                  <ul class="items_content">
                      <li>Ver <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">Puntos de Pago Autorizados </a>.</li>
                  </ul>
              </div>`,
          facturas5f: `
              <div>
                  <h3 class="subtitulo_content">¿Cómo puedo realizar mis pagos?</h3>
                  <p class="items_content">Puedes realizar tus pagos en efectivo, en línea por medio de nuestras plataformas digitales, tu banca en línea o registrando tus cuentas y/o tarjeta de crédito de forma recurrente a través de nuestros canales digitales.</p>
                  <ul class="items_content">
                      <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                      <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                      <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
                      <li>Ver <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Mi Xtrim">Puntos de Pago Autorizados </a>.</li>
                      <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
    <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                  </ul>
              </div>`,    
          facturas6f: `
              <div>
                  <h3 class="subtitulo_content">¿Puedo actualizar mi forma de pago?</h3>
                  <p class="items_content">Sí, puedes actualizar tu forma de pago a Débito Automático a través de nuestros canales digitales: App Mi Xtrim, portal Mi Xtrim ingresando con tus credenciales, también puedes contactarte a nuestro Chatbot al 0968600400, o descargando la solicitud y acercándote a nuestras oficinas a nivel nacional.</p>
                  <ul class="items_content">
                      <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                      <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                      <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      <li><a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Chatea con nosotros</a>.</li>
                      <li>Descarga el formulario <a href="https://www.xtrim.com.ec/wp-content/uploads/2024/01/231026-AUTORIZACION-DE-DEBITO-AUTOMATICO.pdf" target="_blank" title="Cambio forma de Pago">aquí</a>.</li>
                      <li>Si aún no tienes usuario Mi Xtrim puedes registrarte por nuestra app.</li>
    <!-- <li>Si aún no tienes usuario Mi Xtrim click <a href="https://autoservicio.xtrim.com.ec/autenticacion/registro" target="_blank" title="Registrate Aquí">aquí</a>.</li> -->
                  </ul>
              </div>`,
          facturas7f: `
                  <div>
                      <h3 class="subtitulo_content">¿Cuándo debo pagar mis facturas?</h3>
                      <p class="items_content">Realiza el pago de tus facturas los <b>primeros 10 días de cada mes</b>. Disfruta de tu servicio sin interrupciones realizando tus pagos a tiempo.</p>
                      <p class="items_content">Si tu pago es en <b>Efectivo</b> puedes realizarlo a través de los canales autorizados:</p>
                      <p class="items_content"><b>Presenciales</b></p>
                      <ul class="items_content">
                        <li>Red de Pagos <a href="https://www.xtrim.com.ec/red-de-pagos/" target="_blank" title="Portal Web Mi Xtrim">aquí</a>.</li>
                      </ul>
                      <p class="items_content"><b>Digitales</b></p>
                      <ul class="items_content">
                        <li>Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a>.</li>
                        <li class="app_responsive_desktop">Escanea el siguiente QR para descargar la app.<br/><img decoding="async" style="width: 140.75px; height: 140.75px" src="https://www.xtrim.com.ec/wp-content/uploads/2024/02/autoservicio-qrapp.png"></li>
                        <li class="app_responsive_mobile">Descarga la App Mi Xtrim <a href="https://www.mixtrim.com.ec/qr-mixtrim" target="_blank" title="App Mi Xtrim">aquí</a>.</li>
                      </ul>
                      <p class="items_content">Si tu forma de pago es <b>Débito Automático</b>, mantener los fondos correspondientes al monto de tu factura para se pueda realizar el débito.</p>
                      <p class="items_content">Si vas a realizar el pago de tu <b>Primera factura</b>, debes tener en consideración lo siguiente: </p>
                      <ul class="items_content">
                        <li>Tu factura se enviará a tu correo electrónico al día siguiente de activar el servicio.</li>
                        <li>Si la instalación se realiza después del día 20, los días proporcionales se sumarán a la factura del mes siguiente. El 1 del mes siguiente recibirás una factura que incluirá el valor del mes en curso, junto con el proporcional correspondiente al mes de activación.</li>
                      </ul>
                      <p class="items_content">Recuerda que tus promociones se encuentran relacionadas a la puntualidad de tus pagos, evita perder los beneficios de tu contrato manteniéndote al día en tus pagos.</p>
                  </div>` ,
          facturas8f: `
                  <div>
                      <h3 class="subtitulo_content">¿Por qué mi forma de pago cambió a efectivo?</h3>
                      <p class="items_content">Este cambio se realiza automáticamente cuando hemos intentado procesar el débito correspondiente a tu(s) factura(s) de tu cuenta bancaria o tarjeta de crédito en varias ocasiones sin éxito. Esto puede deberse a:</p>
                      <ul class="items_content">
                          <li>Fondos insuficientes.</li>
                          <li>Tarjeta caducada.</li>
                          <li>Cuenta cerrada o bloqueada.</li>
                      </ul>
                      <p class="items_content">Al realizarse este cambio, los beneficios promocionales que disfrutabas podrían verse afectados, es decir, podrías perder megas adicionales, descuentos por forma de pago con el que fue contratado el servicio o plataformas de streaming adicionales. Te recomendamos mantener siempre actualizados tus datos bancarios y validar la información de tu forma de pago en caso de que tus pagos no hayan sido debitados a tiempo.</p>
                  </div>`,
          facturas9f: `
                  <div>
                      <h3 class="subtitulo_content">¿Por qué incrementó mi facturación?</h3>
                      <p class="items_content">Si has notado un aumento en tu facturación, podría deberse a varios motivos. A continuación, te explicamos algunas de las razones más comunes:</p>
                      <p class="items_content">1. <b>Visitas Técnicas:</b> Las órdenes técnicas que son facturadas tienen los siguientes costos según el tipo de red: </p>
                      <ul class="items_content">
                          <li><b>Conexión Hibrida:</b> $15 + impuestos.</li>
                          <li><b>Fibra Óptica:</b> $20 + impuestos.</li>  
                      </ul>
                      <p class="items_content">2. <b>Cambio de Dirección:</b> Las peticiones de cambio de dirección solicitadas por el cliente tienen costo según el tipo de red: </p>  
                      <ul class="items_content">
                            <li><b>Conexión Hibrida:</b> $17.85 + impuestos.</li>
                            <li><b>Fibra Óptica:</b> $35 + impuestos.</li>  
                      </ul>
                      <p class="items_content">3. <b>Productos o Servicios Adicionales:</b> Los productos adicionales tienen los siguientes costos: </p>
                      <ul class="items_content">
                        <li><b>Max:</b> $5.99 incl. impuestos.</li>
                        <li><b>Paramount+:</b> $4.99 incl. impuestos.</li>
                        <li><b>ECDF:</b> $9.99 incl. impuestos.</li>
                        <li><b>Wifi Elite:</b> $4.60 incl. impuestos.</li>
                        <li><b>Control Remoto:</b> Por la compra de un control: $10 + impuestos.</li>
                        <li><b>Tv Box:</b> Por la compra de un equipo Tv Box.</li>
                        <li style="list-style-type: none;">
                          <ul class="items_content">
                            <li><b>Pago de Contado:</b> $70 + impuestos.</li>
                          </ul>
                        </li>
                        <li style="list-style-type: none;">
                          <ul class="items_content">
                            <li><b>Pago de Diferido:</b> $85 + impuestos.</li>
                          </ul>
                        </li>
                      </ul>
    <!-- <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> -->
                      <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>
                  </div>`,
            facturas10f: `
                  <div>
                      <h3 class="subtitulo_content">¿Por qué aparezco reportado en el buró de crédito?</h3>
                      <p class="items_content">Aparecer en el buró de crédito puede ocurrir por diferentes motivos relacionados con el manejo tus pagos en el pasado. A continuación, te mencionamos algunos motivos:</p>
                      <ul class="items_content">
                          <li>Por valores no cancelados oportunamente de tus servicios.</li>
                      </ul>
    <!-- <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p> -->
                      <p class="items_content">Consulta tus saldos y facturas de manera fácil y segura ingresando a <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">Mi Xtrim Web</a>.</p>
                  </div>`,
            internet_preguntaf1: `
                  <div class="answer" id="respuestaf1">
                      <h3 class="subtitulo_content">¿Qué debo hacer si mi módem (y/o) router no encienden?</h3>
                      <p class="items_content">Si tu módem (y/o) router no encienden sigue los siguientes pasos: </p>
                      <p class="items_content">1. Verifica las conexiones.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que el <b>módem (y/o) router</b> estén correctamente conectados a un tomacorriente.</li>
                      </ul>
                      <p class="items_content">2. Prueba con otro tomacorriente.</p>
                      <ul class="items_content">
                          <li>Si todo está bien conectado y el equipo no enciende, intenta enchufarlo en otro tomacorriente. </li>
                      </ul>
                      <!-- <p class="items_content">3. Si el problema persiste.</p>
                      <ul class="items_content">
                      <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                          <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                      </ul> -->
                      <p class="items_content">3. Si el problema persiste y el equipo sigue sin encender, es posible que requieras asistencia técnica, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                internet_preguntaf2: `
                  <div class="answer" id="respuestaf2">
                      <h3 class="subtitulo_content">¿Qué hago si no tengo servicio de internet y mi módem muestra luces intermitentes?</h3>
                      <p class="items_content">Si experimentas dificultades con tu conexión a internet, te sugerimos seguir los siguientes pasos: </p>
                      <p class="items_content">1. Revisa el estado de las luces de tu módem.</p>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>Para red de Fibra Híbrida (HFC):</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Módem Motorola:</b> Revisa las luces <b>"SEND" y "RECEIVE"</b> intermitentes o parpadeando.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Módem Arris:</b> Revisa las luces <b>"US" y "DS"</b> intermitentes o parpadeando.</li>
                            </ul>
                          </li>
                      </ul>
                      <ul class="items_content" style="list-style-type: none;">
                      <li><b>Para red de Fibra (GPON):</b> </li>
                      <li>
                        <ul class="items_content">
                          <li><b>Equipo ZTE:</b> Revisa si la luz <b>"LOS"</b> está encendida.</li>
                        </ul>
                      </li>
                  </ul>
                      <p class="items_content">2. Si las luces de tu equipo presentan las características del <b>punto 1</b>, sugerimos realizar un <b>reinicio.</b></p>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>A. Procedimiento de reinicio:</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>a. Desconectar:</b> Desenchufa el equipo módem de la toma eléctrica.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>b. Esperar:</b> Deja transcurrir 1 minuto antes de conectar nuevamente el equipo.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>c. Conectar:</b> Enchufa nuevamente el equipo a la toma eléctrica.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>d. Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos.</li>
                            </ul>
                          </li>
                      </ul>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>B. Después de reiniciar, revisa el estado de las luces de tu equipo:</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Luz de Power:</b> Debe estar fija.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Luces SEND/RECEIVE o US/DS o LOS:</b> Si continúan intermitentes, necesitarás asistencia técnica.</li>
                            </ul>
                          </li>
                      </ul>
                         <!-- <p class="items_content">3. Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                         <p class="items_content">3. Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                      <p class="items_content">3. Si realizaste las pruebas sugeridas y el problema persiste, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
              internet_preguntaf3: `
                  <div class="answer" id="respuestaf3">
                      <h3 class="subtitulo_content">¿Qué debo hacer si no tengo servicio de internet y mi módem tiene luces fijas?</h3>
                      <p class="items_content">Si no tienes servicio de internet realiza los siguientes pasos:</p>
                      <p class="items_content">1. Revisa las luces en tu equipo.</p>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>Para red de Fibra Híbrida (HFC):</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Módem Motorola:</b> Revisa que las luces <b>"SEND" y "RECEIVE"</b> estén encendidas.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Módem Arris:</b> Revisa que las luces <b>"US" y "DS"</b> estén encendidas.</li>
                            </ul>
                          </li>
                      </ul>
                      <ul class="items_content" style="list-style-type: none;">
                      <li><b>Para red de Fibra (GPON):</b> </li>
                      <li>
                        <ul class="items_content">
                                <li><b>Equipo ZTE:</b> Revisa que las luces <b>"PON"</b> e <b>"INTERNET"</b> estén encendidas.</li>
                              </ul>
                            </li>
                        </ul>
                      <p class="items_content">2. Si las luces están encendidas.</p>
                      <ul class="items_content">
                          <li>Esto indica que hay señal hasta el módem. Posiblemente, el equipo está inhibido y necesita ser reiniciado. </li>
                      </ul>
                      <p class="items_content">3. Reinicia el equipo.</p>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>Procedimiento de reinicio:</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Desconectar:</b> Desenchufa el equipo módem de la toma eléctrica.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Esperar:</b> Deja transcurrir 1 minuto antes de conectar nuevamente el equipo.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Conectar:</b> Enchufa nuevamente el equipo a la toma eléctrica.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos y puedas verificar el servicio.</li>
                            </ul>
                          </li>
                      </ul>
                      <p class="items_content">4. Verifiquemos el servicio.</p>
                      <ul class="items_content">
                          <li>Si aún no tienes internet, repite el reinicio como se describe en el <b>paso 3</b>, pero esta vez, reinicia tanto el <b>módem como el router wifi.</b></li>
                      </ul>
                         <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                         <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                      <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino has podido resolver el problema, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                internet_preguntaf4: `
                  <div class="answer" id="respuestaf4">
                      <h3 class="subtitulo_content">¿Cómo soluciono la intermitencia en mi servicio de internet?</h3>
                      <p class="items_content">Si tienes el servicio de internet intermitente realizaremos los siguientes pasos:</p>
                      <p class="items_content">1. Revisar la Conexión Física.</p>
                      <ul class="items_content">
                          <li><b>Cableado:</b> Asegúrate de que todos los cables estén bien conectados, tanto el cable de alimentación eléctrica del <b>módem y router</b>, como los cables Ethernet.</li>
                      </ul>
                      <p class="items_content">2. Revisemos detalles de nuestra red wifi.</p>
                      <ul class="items_content">
                          <li><b>Ubicación del Router:</b> El router debe estar en un lugar central de tu casa y lejos de objetos que puedan causar interferencia (microondas, teléfonos inalámbricos, etc.).</li>
                          <li><b>Ubicación de nuestro dispositivo:</b> Para descartar que la intermitencia no sea debido a la ubicación de nuestro dispositivo <b>(celular, laptop, pc)</b> sugerimos ubicarnos cerca del router y comprobar si el problema persiste o si se soluciona con este paso.</li>
                          <li><b>Desconectar Dispositivos Innecesarios:</b> Apaga o desconecta dispositivos que no estés utilizando y que puedan estar usando la red.</li>
                      </ul>
                      <p class="items_content">3. Reiniciar dispositivos.</p>
                      <ul class="items_content">
                          <li><b>Reiniciar el Módem y el Router:</b> Desenchufa el <b>módem y el router</b> esperando durante al menos <b>30 segundos a 1 minuto</b> y luego de ese tiempo vuélvelos a conectar.</li>
                          <li><b>Reiniciar Dispositivos de Conexión:</b> Desconecta los dispositivos que se conectan a la red wifi (computadoras, teléfonos, tablets).</li>
                      </ul>
                         <!-- <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                         <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea(Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                      <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio, sino has podido resolver el problema, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  internet_preguntaf5: ` 
                  <div class="answer" id="respuestaf5">
                      <h3 class="subtitulo_content">¿Qué puedo hacer si mi servicio de internet está lento?</h3>
                      <p class="items_content">Si tienes el servicio de internet lento realizaremos los siguientes pasos:</p>
                      <p class="items_content">1. Revisemos detalles de nuestra red wifi que pueden estar causando una navegación lenta:</p>
                      <ul class="items_content">
                          <li><b>Ubicación del Router:</b> El router debe estar en un lugar elevado o central de tu casa y lejos de objetos que puedan causar interferencia (microondas, teléfonos inalámbricos, etc.).</li>
                          <li><b>Desconectar Dispositivos Innecesarios:</b> Apaga o desconecta dispositivos que no estés utilizando y que puedan estar usando la red wifi.</li>
                          <li>Si persiste el inconveniente, realizamos lo mencionado en el paso 2.</li>
                      </ul>
                      <p class="items_content">2. Revisar si existe lentitud en otros dispositivos conectados a la red.</p>
                      <ul class="items_content">
                          <li><b>Lentitud:</b> Se considera lentitud en la navegación si ocurre en todos los dispositivos conectados a la red <b>(celular, laptop, tablets, PC)</b>. Si solo ocurre en uno es probable que el inconveniente se esté dando solo con ese dispositivo.</li>
                          <li>Si persiste el inconveniente, realizamos lo mencionado en el paso 3.</li>
                      </ul>
                      <p class="items_content">3. Realizar una prueba para medir la velocidad de navegación considerando los siguientes puntos: </p>
                      <ul class="items_content">
                          <li><b>Pruebas en red:</b> Para una mejor efectividad y resultados más precisos en la medición, desconecta los demás dispositivos que estén conectados a la red wifi, dejando únicamente el dispositivo desde el cual realizaremos la prueba de velocidad ingresando en nuestro navegador al enlace del medidor (http://xtrim.speedtestcustom.com/)</li>
                          <li><b>Pruebas con PC directo:</b> Desconecta los dispositivos que se conectan a la red wifi (computadoras, teléfonos, tablets).</li>
                          <li style="list-style-type: none;">
                              <ul class="items_content">
                                <li>Desconecta el cable de red <b>(ethernet)</b> que va desde el modem hacia el puerto detrás del router.</li>
                                <li>Conecta el cable que acabamos de desconectar del puerto del router y lo conectaremos en el puerto de red de nuestra laptop o PC.</li>
                                <li>Abrimos el navegador y realizaremos la prueba de velocidad ingresando al enlace del medidor (http://xtrim.speedtestcustom.com/)</li>
                                <li>Una vez realizada la prueba reubicar el cable detrás del router en su respectivo puerto de red.</li>
                                <li>Si persiste el inconveniente, realizamos lo mencionado en el paso 4.</li>
                              </ul>
                          </li>
                      </ul>
                      <p class="items_content">4. Reiniciar dispositivos.</p>
                      <ul class="items_content">
                          <li><b>Reiniciar el Módem y el Router:</b> Reinicia el <b>módem y el router</b> desconectándolos durante al menos <b>30 segundos a 1 minuto</b> y luego de ese tiempo vuélvelos a conectar.</li>
                          <li><b>Reiniciar Dispositivos de Conexión:</b> Reinicia los dispositivos que se conectan a la red wifi (computadoras, teléfonos, tablets).</li>
                      </ul>
                         <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                         <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                      <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino has podido resolver el problema, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  internet_preguntaf6: `
                  <div class="answer" id="respuestaf6">
                      <h3 class="subtitulo_content">¿Cómo puedo cambiar la contraseña de mi wifi?</h3>
                         <!-- <p class="items_content">1. <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p> -->
                      <p class="items_content">1. <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p>
                      <p class="items_content">2. Selecciona la <b>opción 1</b> "Ya soy cliente".</p>
                      <p class="items_content">3. Ingresa tu número de <b>Cédula/RUC/Pasaporte.</b></p>
                      <p class="items_content">4. Selecciona la cuenta del contrato de internet.</b></p>
                      <p class="items_content">5. El Bot mostrará el menú de opciones.</b></p>
                      <p class="items_content">6. Selecciona la <b>opción 2</b> "Ayuda con mi Servicio".</b></p>
                      <p class="items_content">7. Selecciona la <b>opción 3</b> "Configurar mi wifi". </b></p>
                      <p class="items_content">8. Escoge la acción que desea realizar con tu equipo Wifi:</b></p>
                      <ul class="items_content">
                          <li><b>Opción 1</b> - Cambio de Contraseña</li>
                          <li><b>Opción 2</b> - Cambiar nombre de mi red Wifi.</li>
                      </ul>
                      <p class="items_content">9. Siguiendo estos pasos deberías haber podido cambiar la contraseña de tu red Wifi. </p>
                  </div>`,
                  internet_preguntaf7: `
                  <div class="answer" id="respuestaf7">
                      <h3 class="subtitulo_content">¿Qué es una incidencia o daño en el sector?</h3>
                      <p class="items_content">Un incidente o daño del sector es cualquier evento inesperado que puede provocar una interrupción en el servicio.</p>
                  </div>`,
                  internet_preguntaf8: `
                  <div class="answer" id="respuestaf8">
                        <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de internet por motivo de vacaciones? </h3>
                        <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                        <p class="items_content"><b>Requisitos: </b></p>
                        <ul class="items_content">
                            <li>Es importante que los pagos del servicio estén al día previo a realizar la solicitud antes de la fecha de vencimiento de la factura.</li>
                            <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                            <li>Al finalizar el periodo de suspensión temporal, el contrato se reactivará de manera automática.</li>
                            <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                         <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                         <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                            <li>Gestiona esta solicitud en el canal de atención de tu preferencia:</li>
                            <li style="list-style-type: none;">
                                  <ul class="items_content">
                                      <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                                      <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                                  </ul>
                             </li>
                        </ul>
                    </div>`,
                    telefonia_preguntaf9: `
                  <div class="answer" id="respuestaf9">
                      <h3 class="subtitulo_content">¿Qué pasos debo seguir si no tengo tono en mi línea telefónica?</h3>
                      <p class="items_content">1. Revisa que el equipo de telefonía <b>(ARRIS o ZTE)</b> esté encendido.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que las luces del equipo estén encendidas.</li>
                      </ul>
                      <p class="items_content">2. Verifica las conexiones.</p>
                      <ul class="items_content">
                          <li>Comprueba que los cables estén bien conectados entre el equipo de telefonía <b>(ARRIS o ZTE)</b> y la base telefónica <b>(teléfono)</b>.</li>
                      </ul>
                      <p class="items_content">3. Reinicia el equipo.</p>
                      <ul class="items_content">
                          <li><b>Desconectar:</b> Desconecta el equipo de telefonía <b>(ARRIS o ZTE)</b> de la toma eléctrica.</li>
                          <li><b>Esperar:</b> Espera 1 minuto.</li>
                          <li><b>Conectar:</b> Vuelve a conectar el equipo a la toma eléctrica.</li>
                          <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos.</li>
                      </ul>
                      <p class="items_content">4. Probar el servicio verificando si se restableció el tono de la línea.</p>
                         <!-- <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p>
                         <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino lo has podido resolver accede a nuestro diagnóstico en línea (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para realizar el diagnóstico).</p> -->
                      <p class="items_content">5. Siguiendo estos pasos debería restablecerse tu servicio, sino has podido resolver el problema, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  telefonia_preguntaf10: `
                  <div class="answer" id="respuestaf10">
                      <h3 class="subtitulo_content">¿Qué puedo hacer si mi equipo de telefonía no enciende?</h3>
                      <p class="items_content">1. Verifica las conexiones.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que el equipo de telefonía <b>(ARRIS o ZTE)</b> esté conectado a un tomacorriente.</li>
                      </ul>
                      <p class="items_content">2. Prueba otra toma eléctrica.</p>
                      <ul class="items_content">
                          <li>Si todo está bien conectado pero el equipo no enciende, prueba enchufarlo en otro tomacorriente.</li>
                      </ul>
                      <!-- <p class="items_content">3. Si el problema persiste.</p>
                      <ul class="items_content">
                          <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                          <li>Si el equipo sigue sin encender, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</li>
                      </ul> -->
                      <p class="items_content">3. Si el problema persiste y el equipo sigue sin encender, es posible que requieras asistencia técnica, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  telefonia_preguntaf11: `
                  <div class="answer" id="respuestaf11">
                      <h3 class="subtitulo_content">¿Por qué mi teléfono no suena cuando recibo llamadas?</h3>
                      <p class="items_content">1. Revisa que el equipo de telefonía <b>(ARRIS o ZTE)</b> esté encendido.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que las luces del equipo estén encendidas.</li>
                      </ul>
                      <p class="items_content">2. Verifica las conexiones.</p>
                      <ul class="items_content">
                          <li>Comprueba que los cables estén bien conectados entre el equipo de telefonía <b>(ARRIS o ZTE)</b> y la base telefónica <b>(teléfono)</b>.</li>
                      </ul>
                      <p class="items_content">3. Verifica el volumen del timbre.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que el volumen del timbre del teléfono o de la base telefónica esté ajustado adecuadamente.</li>
                      </ul>
                      <p class="items_content">4. Prueba con otra base telefónica <b>(teléfono)</b>.</p>
                      <ul class="items_content">
                          <li>Si es posible, conecta otro teléfono o base telefónica para ver si el problema persiste.</li>
                      </ul>
                  </div>`,
                  telefonia_preguntaf12: `
                  <div class="answer" id="respuestaf12">
                      <h3 class="subtitulo_content">¿Por qué hay ruido en mi línea telefónica y cómo puedo solucionarlo?</h3>
                      <p class="items_content">1. Verifica las conexiones.</p>
                      <ul class="items_content">
                          <li>Comprueba que los cables estén bien conectados entre el equipo de telefonía (ARRIS o ZTE) y la base telefónica (teléfono).</li>
                          <li>Revisa que los cables no se encuentren en mal estado, descartando que estén torcidos, cortados, desgastados.</li>
                      </ul>
                      <p class="items_content">2. Reinicia el equipo.</p>
                      <ul class="items_content">
                          <li><b>Desconectar:</b> Desconecta el equipo de telefonía <b>(ARRIS o ZTE)</b> de la toma eléctrica.</li>
                          <li><b>Esperar:</b> Espera 1 minuto.</li>
                          <li><b>Conectar:</b> Vuelve a conectar el equipo a la toma eléctrica.</li>
                          <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos.</li>
                      </ul>
                      <p class="items_content">3. Probar el servicio verificando si se al realizar la llamada ya no se presenta el ruido en la línea.</p>
                      <p class="items_content">4. Siguiendo estos pasos debería restablecerse tu servicio.</p>
                  </div>`,
                  telefonia_preguntaf13: `
                  <div class="answer" id="respuestaf13">
                      <h3 class="subtitulo_content">¿Qué debo hacer si no puedo realizar llamadas a destinos específicos?</h3>
                      <p class="items_content">1. Verifica el número.</p>
                      <ul class="items_content">
                          <li>Asegúrate de que el número al que intentas llamar tiene la cantidad correcta de dígitos.</li>
                      </ul>
                      <p class="items_content">2. Para llamadas nacionales revisa que el prefijo sea el correcto.</p>
                      <ul class="items_content" style="list-style-type: none;">
                          <li><b>Valida el prefijo provincial según la provincia:</b> </li>
                          <li>
                            <ul class="items_content">
                              <li><b>02:</b> Pichincha, Sto. Domingo.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>03:</b> Bolívar, Chimborazo, Cotopaxi, Tungurahua, Pastaza.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>04:</b> Guayas, Santa Elena.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>05:</b> Galápagos, Los Ríos, Manabí.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>06:</b> Carchi, Esmeraldas, Imbabura, Napo, Orellana, Sucumbíos.</li>
                            </ul>
                          </li>
                          <li>
                            <ul class="items_content">
                              <li><b>07:</b> Azuay, Cañar, El Oro, Loja, Morona, Zamora.</li>
                            </ul>
                          </li>
                      </ul>
                      <p class="items_content">3. Llamadas internacionales:</p>
                      <ul class="items_content" style="list-style-type: none;">
                      <li><b>Valida el código de país y el código de área:</b> </li>
                      <li>
                        <ul class="items_content">
                          <li>Por ejemplo, para llamar a Ecuador: <b>Código de País</b> (593) + <b>Código de Área Guayas</b> (4) + <b>Número local</b> (6002400). </li>
                        </ul>
                      </li>
                      <p class="items_content">4. Posterior a la revisión de los puntos anteriores, podrías intentar realizar la llamada nuevamente.</p>
                  </div>`,
                telefonia_preguntaf14: `
                  <div class="answer" id="respuestaf14">
                      <h3 class="subtitulo_content">¿Cómo bloquear/desbloquear llamadas?</h3>
                      <p class="items_content"><b>Bloqueo / Desbloqueo de llamadas:</b></p>
                      <ul class="items_content">
                          <li>Temporal o variable: Se debe marcar la combinación <b>*20 + PIN + * + número de celular, internacional o nacional</b>.</li>
                          <li>Prolongado: Se debe marcar <b>*33#</b> y elegir la <b>opción 1</b> (bloquear y desbloquear). En el caso que se requiera cambiar PIN la <b>opción 2</b>.</li>
                      </ul>
                  </div>`,
                  telefonia_preguntaf15: `
                    <div class="answer" id="respuestaf15">
                        <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de telefonía por motivo de vacaciones? </h3>
                        <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                        <p class="items_content"><b>Requisitos: </b></p>
                        <ul class="items_content">
                            <li>Es importante que los pagos del servicio estén al día antes de realizar la solicitud.</li>
                            <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                            <li>Al finalizar el periodo de suspensión temporal, el contrato se reactivará de manera automática.</li>
                            <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                            <li>Se aplican costos de la tarifa básica de telefonía.</b></li>
                         <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                         <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                         <li>Gestiona esta solicitud en el canal de atención de tu preferencia:</li>
                         <li style="list-style-type: none;">
                              <ul class="items_content">
                                  <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                                  <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                              </ul>
                          </li>
                        </ul>
                    </div>`,
                    tv_streaming_preguntaf16: `
                  <div class="answer" id="respuestaf16">
                      <h3 class="subtitulo_content">¿Qué hacer si tu pantalla esta de color negra, azul o roja?</h3>
                      <p class="items_content">1. Verifica las conexiones entre tu decodificador y tu TV.</p>
                      <ul class="items_content">
                          <li>Comprueba que los cables estén bien conectados y ajustados.</li>
                          <li>Revisa que los cables se encuentran en buen estado descartando que estén torcidos, cortados, desgastados.</li>
                      </ul>
                      <p class="items_content">2. Reinicia el equipo decodificador.</p>
                      <ul class="items_content">
                          <li><b>Desconectar:</b> Desconecta el equipo decodificador de la toma eléctrica.</li>
                          <li><b>Esperar:</b> Espera 1 minuto.</li>
                          <li><b>Conectar:</b> Vuelve a conectar el equipo a la toma eléctrica.</li>
                          <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos.</li>
                      </ul>
                         <!-- <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                         <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                      <p class="items_content">3. Si el problema persiste y el equipo sigue sin encender, es posible que requieras asistencia técnica, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  tv_streaming_preguntaf17: `
                  <div class="answer" id="respuestaf17">
                      <h3 class="subtitulo_content">¿Cómo configurar mi control remoto?</h3>
                         <!-- <p class="items_content">1. <a href="https://api.whatsapp.com/send/?phone=593968600400&text&type=phone_number&app_absent=0" target="_blank" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p> -->
                      <p class="items_content">1. <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Chatbot">Ingresa a nuestro canal Bot</a>.</p>
                      <p class="items_content">2. Selecciona la <b>opción 1</b> "Ya soy cliente".</p>
                      <p class="items_content">3. Ingresa tu número de <b>Cédula/RUC/Pasaporte.</b></p>
                      <p class="items_content">4. Selecciona la cuenta del contrato donde tengas el servicio de televisión.</b></p>
                      <p class="items_content">5. El Bot mostrará el menú de opciones.</b></p>
                      <p class="items_content">6. Selecciona la <b>opción 7</b> "Instructivos".</b></p>
                      <p class="items_content">7. Selecciona la <b>opción 3</b> "Control remoto". </b></p>
                      <p class="items_content">8. Sigue los pasos del instructivo para que puedas configurar tu control remoto.</b></p>
                  </div>`,
                  tv_streaming_preguntaf18: `
                  <div class="answer" id="respuestaf18">
                      <h3 class="subtitulo_content">¿Se averió mi control remoto necesito uno nuevo?</h3>
                      <p class="items_content">1. Reemplaza las baterías de tu control remoto por unas nuevas, para descartar que se hayan desgastado.</p>
                      <p class="items_content">2. Si cambiaste de baterías y al pulsar los botones no se encienden significa que debes cambiar de control de remoto.</p>
                      <!-- <p class="items_content">3. Para adquirir un control nuevo puedes ingresar <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/compra-tv-box" target="_blank" title="TV Box/Control Remoto">aquí</a>.</p> -->
                      <p class="items_content">3. Para adquirir un control nuevo puedes ingresar acercarte a uno de nuestros centros de atención. Conoce la agencia más cercana <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</p>
                  </div>`,
                  tv_streaming_preguntaf19: `
                  <div class="answer" id="respuestaf19">
                      <h3 class="subtitulo_content">¿No tengo audio ni video?</h3>
                      <p class="items_content">1. Verifica las conexiones entre tu decodificador y tu TV.</p>
                      <ul class="items_content">
                          <li>Comprueba que los cables estén bien conectados y ajustados.</li>
                          <li>Revisa que los cables se encuentran en buen estado descartando que estén torcidos, cortados, desgastados.</li>
                      </ul>
                      <p class="items_content">2. Reinicia el equipo decodificador.</p>
                      <ul class="items_content">
                          <li><b>Desconectar:</b> Desconecta el equipo decodificador de la toma eléctrica.</li>
                          <li><b>Esperar:</b> Espera 1 minuto.</li>
                          <li><b>Conectar:</b> Vuelve a conectar el equipo a la toma eléctrica.</li>
                          <li><b>Cargar:</b> Espera 2 minutos para que el equipo se ajuste en sus niveles correctos.</li>
                      </ul>
                          <!-- <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a href="https://autoservicio.xtrim.com.ec/autenticacion/iniciar-sesion" target="_blank" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p>
                          <p class="items_content">3. Probar y verificar si se solvento el inconveniente. Si el problema persiste, necesitarás asistencia técnica (Ingresa al portal web Mi Xtrim <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Portal Web Mi Xtrim">aquí</a> para más detalles).</p> -->
                      <p class="items_content">3. Siguiendo estos pasos debería restablecerse tu servicio, sino has podido resolver el problema, selecciona tu canal de atención preferido.</p>
                      <ul class="items_content">
                          <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                          <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                      </ul>
                  </div>`,
                  tv_streaming_preguntaf20: `
                  <div class="answer" id="respuestaf20">
                      <h3 class="subtitulo_content">¿Qué es Xtrim Play?</h3>
                      <p class="items_content">Es una plataforma de entretenimiento de Xtrim, donde encontrarás canales en vivo, series, películas, deportes y más, todo en HD y accesible desde cualquier dispositivo, en cualquier momento.
                      </p>
                  </div>`,
                  tv_streaming_preguntaf21: `
                  <div class="answer" id="respuestaf21">
                      <h3 class="subtitulo_content">¿Cómo recuperar mi contraseña de Xtrim Play?</h3>
                         <!-- <p class="items_content">1. Puedes recuperar tu contraseña de Xtrim Play <a href="https://autoservicio.xtrim.com.ec/autenticacion/olvido-clave " target="_blank" title="Xtrim Play">aquí</a>.</p> -->
                      <p class="items_content">1. Puedes recuperar tu contraseña de Xtrim Play <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Xtrim Play">aquí</a>.</p>
                  </div>`,
                  tv_streaming_preguntaf22: `
                  <div class="answer" id="respuestaf22">
                      <h3 class="subtitulo_content">¿Qué es una incidencia o daño en el sector?</h3>
                      <p class="items_content">Un incidente o daño del sector es cualquier evento inesperado que puede provocar una interrupción en el servicio.</p>
                  </div>`,
                  tv_streaming_preguntaf23: `
                  <div class="answer" id="respuestaf23">
                      <h3 class="subtitulo_content">¿Cómo acceder a canales de HD?</h3>
                      <p class="items_content">1. Cambiarse de plan o solicitar el paquete de canales en HD.</p>
                      <p class="items_content">2. Comunicarse para asesoría telefoníca al <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">"Call Center"</a>.</p>
                  </div>`,
                  tv_streaming_preguntaf24: `
                    <div class="answer" id="respuestaf24">
                        <h3 class="subtitulo_content">¿Puedo suspender temporalmente mi servicio de televisión por motivo de vacaciones? </h3>
                        <p class="items_content">Si vas a salir de viaje y no harás uso de tu servicio es posible solicitar una suspensión de forma temporal.</p>
                        <p class="items_content"><b>Requisitos: </b></p>
                        <ul class="items_content">
                            <li>Es importante que los pagos del servicio estén al día antes de realizar la solicitud.</li>
                            <li>La suspensión del servicio es posible por un período <b>mínimo de 15 días y máximo de 60 días.</b></li>
                            <li>Al finalizar el período de suspensión temporal, el contrato se reactivará de manera automática.</li>
                            <li>Se genera un costo por reconexión de <b>$3 + impuestos.</b></li>
                         <!-- <li>Puedes acceder a esta solicitud ingresando <a href="https://autoservicio.xtrim.com.ec/consultas-solicitudes/suspension-temporal" target="_blank" title="Suspensión Temporal">aquí</a>.</li>
                         <li>Puedes acceder a esta solicitud ingresando <a class="open-modal_mantenimiento" style="cursor:pointer;" title="Suspensión Temporal">aquí</a>.</li> -->
                         <li>Gestiona esta solicitud en el canal de atención de tu preferencia:</li>
                         <li style="list-style-type: none;">
                              <ul class="items_content">
                                  <li><b>Atención presencial: </b>Encuentra nuestras agencias cercanas y recibe atención personalizada <a href="https://www.xtrim.com.ec/canales-presenciales/" target="_blank" title="Canales Presenciales">aquí</a>.</li>
                                  <li><b>Atención telefónica: </b>Si prefieres hablar con uno de nuestros asesores, comunícate con nuestro Callcenter <a href="https://www.xtrim.com.ec/call-center/" target="_blank" title="Call Center">aquí</a>.</li>
                              </ul>
                          </li>
                        </ul>
                    </div>`,    
                tv_streaming_preguntaf25: `
                    <div class="answer" id="respuestaf25">
                        <h3 class="subtitulo_content">¿Qué es Zapping?</h3>
                        <p class="items_content">Zapping es una plataforma de entretenimiento Streaming donde podrás ver todos los partidos en directa de la Liga Pro Ecuabet y programación en vivo.</p>
                    </div>`,    
                tv_streaming_preguntaf26: `
                        <div class="answer" id="respuestaf26">
                            <h3 class="subtitulo_content">Si soy cliente xtrim, ¿Cómo puedo contratar los partidos de La Liga Pro Ecuabet?</h3>
                            <ul class="items_content">
                                <li><b>Si eres cliente de TV residencial</b>, tienes totalmente gratis durante el 2024 Zapping Sports en el canal 220 SD y 751 HD.</li>
                                <li><b>Si eres cliente de internet</b>, activa Zapping agregándolo a tu plan de internet. El valor de Zapping se sumará a tu facturación mensual. Puedes activar el servicio de Zapping <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</li>
                            </ul>
                        </div>`,
                tv_streaming_preguntaf27: `
                        <div class="answer" id="respuestaf27">
                            <h3 class="subtitulo_content">Si NO soy cliente xtrim, ¿Puedo ver La Liga Pro Ecuabet?</h3>
                            <p class="items_content">¡Claro que sí!</p>
                            <p class="items_content">Puedes ver la Liga Pro Ecuabet de las siguientes maneras:</p>
                            <ul class="items_content">
                                <li>Contratando el plan X-Futbol que incluye internet de 300*megas + Zapping. <a href="https://wa.me/593968600400" target="_blank" rel="noopener">Contrata Ahora</a>.</li>
                                <li>Suscribiéndote a Zapping con tu tarjeta bancaria por $5,99 al mes. Puedes hacerlo desde <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</li>
                            </ul>
                        </div>`,
                tv_streaming_preguntaf28: `
                        <div class="answer" id="respuestaf28">
                            <h3 class="subtitulo_content">¿En cuántos dispositivos puedo ver al mismo tiempo?</h3>
                            <p class="items_content">Disfruta todo el contenido de Zapping en 5 dispositivos a la vez: 4 conectados a tu red principal y 1 en otra red. Para más detalles, revisa la guía de control de dispositivos <a href="https://www.xtrim.com.ec/contrata-aqui/" target="_blank" rel="noopener">aquí</a>.</p>
                        </div>`,
                tv_streaming_preguntaf29: `
                        <div class="answer" id="respuestaf29">
                            <h3 class="subtitulo_content">¿Qué canales incluye Zapping?</h3>
                            <p class="items_content">Con Zapping tienes +20 canales, incluye programación nacional e internacional y <b>la Liga Pro Ecuabet Serie A*</b> y <b>Serie B**</b> en exclusiva.</p>
                  <div class="channel-container">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/Zapping-ver_.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ECDF-ver_.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ecuavisa.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/Teleamazonas.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/TC.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/rts.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/gamavision.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telerama.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/ecuadorTV.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/TVC.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/uno.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/wuan.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/24-7.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telepremier.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/vitoTV.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/oromar.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/redonda.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/scandalo.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/DW.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/VOA.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/enlace.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/france24.png" class="channel">
                      <img src="https://www.xtrim.com.ec/wp-content/uploads/2024/08/telefe.png" class="channel">
                  </div>
                        </div>`,
                tv_streaming_preguntaf30: `
                        <div class="answer" id="respuestaf30">
                            <h3 class="subtitulo_content">¿Zapping es un servicio legal?</h3>
                            <p class="items_content">Sí, Zapping es una plataforma de contenido legal asegurando la autorización de todo el contenido transmitido.</p>
                        </div>`,
                tv_streaming_preguntaf31: `
                        <div class="answer" id="respuestaf31">
                            <h3 class="subtitulo_content">¿Es segura la plataforma de Zapping?</h3>
                            <p class="items_content">¡Por supuesto! Zapping garantiza la seguridad de tus datos y transacciones, sin almacenar la información de tus medios de pago.</p>
                        </div>`,
                tv_streaming_preguntaf32: `
                        <div class="answer" id="respuestaf32">
                            <h3 class="subtitulo_content">¿Qué puedo hacer si no tengo un Smart TV compatible?</h3>
                            <p class="items_content">Te recomendamos que utilices uno de los dispositivos compatibles para ver Zapping, conócelos <a href="https://www.zapping.ec/compatibilidad" target="_blank" rel="noopener">aquí</a>.</p>
                        </div>`,
                tv_streaming_preguntaf33: `
                        <div class="answer" id="respuestaf33">
                            <h3 class="subtitulo_content">Quiero cancelar mi servicio Zapping. ¿Cómo lo hago?</h3>
                            <ul class="items_content">
                                <li><b>Si eres cliente de Xtrim y activaste Zapping en tu plan de internet:</b> Puedes hacerlo llamando al 600 4000 antes del 23 del mes para evitar que se cobre en tu próxima factura. Una vez que solicites la cancelación, tu servicio seguirá activo hasta el final del mes. Recuerda que debes tener Zapping activo por al menos 30 días.</li>
                                <li><b>Si contrataste Zapping en <a href="https://www.zapping.ec/compatibilidad" target="_blank" rel="noopener">www.zapping.ec</a>:</b> Puedes desactivarlo directamente en la app, y tu servicio se dará de baja de inmediato.</li>
                            </ul>
                        </div>` 
            

    };

    function searchDynamicContent(query) {
        const results = [];
    
        // Recorrer el contenido cargado dinámicamente
        for (let key in contents) {
            if (contents[key].toLowerCase().includes(query.toLowerCase())) {
                
                // Determinar la sección según el key
                let section = '';
                let resultMessage = '';
                let modifiedKey = key;  // Mantendremos una versión modificada de la key para la URL
    
                // Servicios (Internet, Telefonía, TV/Streaming)
                if (key.startsWith('internet_pregunta')) {
                    section = '/centro-de-ayuda/servicios/';
                    modifiedKey = key.replace(/_/g, '-');  // Reemplazar _ por - para la URL
                    const questionNumber = key.split('preguntaf')[1]; // Tomar el número de la pregunta
                    resultMessage = `Resultado encontrado en la pregunta ${questionNumber} del servicio de Internet.`;
                } else if (key.startsWith('telefonia_pregunta')) {
                    section = '/centro-de-ayuda/servicios/';
                    modifiedKey = key.replace(/_/g, '-');  // Reemplazar _ por - para la URL
                    const questionNumber = key.split('preguntaf')[1]; // Tomar el número de la pregunta
                    resultMessage = `Resultado encontrado en la pregunta ${questionNumber} del servicio de Telefonía.`;
                } else if (key.startsWith('tv_streaming_pregunta')) {
                    section = '/centro-de-ayuda/servicios/';
                    // Reemplazar solo el último _ entre streaming y pregunta por -
                    modifiedKey = key.replace('tv_streaming_pregunta', 'tv_streaming-pregunta');
                    const questionNumber = key.split('preguntaf')[1]; // Tomar el número de la pregunta
                    resultMessage = `Resultado encontrado en la pregunta ${questionNumber} del servicio de TV y Streaming.`;
                } 
                // Facturación y Pagos (cambiar "facturasXf" por "contenidoXf")
                else if (key.startsWith('facturas') && key.endsWith('f')) {
                    section = '/centro-de-ayuda/facturacion-y-pagos/';
                    modifiedKey = key.replace('facturas', 'contenido');  // Reemplazar facturasXf por contenidoXf
                    const questionNumber = key.match(/facturas(\d+)f/)[1]; // Extraer el número de la pregunta
                    resultMessage = `Resultado encontrado en la pregunta ${questionNumber} de facturación y pagos.`;
                } 
                // Solicitudes
                else if (key.startsWith('contenido')) {
                    section = '/centro-de-ayuda/solicitudes/';
                    const questionNumber = key.split('contenido')[1]; // Tomar el número de la pregunta
                    resultMessage = `Resultado encontrado en la pregunta ${questionNumber} de solicitudes.`;
                }
    
                // Agregar el resultado a la lista
                results.push({
                    title: resultMessage,  // Título personalizado
                    url: `${window.location.origin}${section}#${modifiedKey}`  // Usar el key modificado en la URL
                });
            }
        }
    
        return results;
    }    
    
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const query = searchInput.value.trim();
    
            if (query.length > 2) {
                // Realizar la petición AJAX para buscar en las páginas y el contenido dinámico
                fetch(`${window.location.origin}/wp-admin/admin-ajax.php?action=help_center_search&query=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
                        resultsContainer.innerHTML = '';
    
                        let dynamicResults = searchDynamicContent(query);
                        let allResults = dynamicResults.concat(data.data);  // Combinar resultados dinámicos y los de la búsqueda en páginas
    
                        if (allResults.length) {
                            allResults.forEach(result => {
                                const resultItem = document.createElement('div');
                                resultItem.className = 'search-result-item';
                                resultItem.innerHTML = `<a href="${result.url}">${result.title}</a>`;
                                resultsContainer.appendChild(resultItem);
                            });
                        } else {
                            resultsContainer.innerHTML = '<p>No se encontraron resultados.</p>';
                        }
                    })
                    .catch(error => {
                        console.error('Error en la búsqueda:', error);
                        resultsContainer.innerHTML = '<p>Hubo un error en la búsqueda. Intenta nuevamente.</p>';
                    });
            } else {
                resultsContainer.innerHTML = '';
            }
        });
    }                    
});

/*Fin del codigo prueba buscador UX*/

